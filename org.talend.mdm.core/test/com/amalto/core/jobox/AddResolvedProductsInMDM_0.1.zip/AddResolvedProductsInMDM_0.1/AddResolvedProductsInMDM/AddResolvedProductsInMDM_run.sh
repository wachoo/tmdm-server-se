cd `dirname $0`
 ROOT_PATH=`pwd`
java -Xms256M -Xmx1024M -cp classpath.jar: product.addresolvedproductsinmdm_0_1.AddResolvedProductsInMDM --context=Default $* 