cd `dirname $0`
 ROOT_PATH=`pwd`
java -Xms256M -Xmx1024M -cp classpath.jar: tests.testtalendmdmjob_0_1.TestTalendMDMJob --context=Default $* 