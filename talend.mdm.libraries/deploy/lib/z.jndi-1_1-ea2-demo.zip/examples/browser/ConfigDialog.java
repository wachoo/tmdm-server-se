/*
 * Copyright (c) 1998 Sun Microsystems, Inc. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * "@(#)ConfigDialog.java	1.1	99/05/06 SMI"
 */

package examples.browser;

import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableColumn;
import javax.swing.event.TableModelEvent;
import javax.swing.event.ChangeEvent;

import java.awt.*;
import java.awt.event.*;
import java.util.Vector;
import java.util.Hashtable;
import java.util.Enumeration;

import javax.naming.Context;

/**
  * This class implements a frame for editing environment properties.
  * After the properties have been changed, the user can apply the
  * changes, at which point the corresponding DirPanel will be
  * re-initialized using the updates.
  *
  * @author Rosanna Lee
  */
class ConfigDialog extends JFrame {
    // Table headings
    static final String[] heading = {"Property Name" , "Property Value"};

    // Table containing property names and value
    JTable table;

    // Data of table
    EnvTableModel tableModel;

    // Original environment property before changes
    Hashtable origEnv;

    // Original root
    String origRoot;

    // Listener to notify when changes to environment properties are applied.
    ConfigListener listener;

    static boolean debug = true;

    ConfigDialog(String origRoot, Hashtable origEnv) {
	super("Configure");

	this.origEnv = origEnv;
	this.origRoot = origRoot;

	// Create table using original environment properties
	tableModel = new EnvTableModel(origEnv);
	table = new JTable(tableModel);

	// Add table to scroller
	JScrollPane tablePane = new JScrollPane(table);
        tablePane.setPreferredSize(new Dimension(500, 100));
	
	// Create panel containing table and buttons
	JPanel panel = new JPanel(new BorderLayout());
	panel.add(tablePane, BorderLayout.CENTER);
	panel.add(createButtonPanel(), BorderLayout.SOUTH);

	// Add root text field to frame
	getContentPane().add(createRootField(origRoot), BorderLayout.NORTH);

	// Add panel to frame
	getContentPane().add(panel, BorderLayout.CENTER);
	setBackground(Color.lightGray);

	// Ensures that frame will be destroyed
	addWindowListener( new WindowAdapter() {
	    public void windowClosing(WindowEvent e) {
		dispose();}} );

	// Make frame visible
	pack();
	show();
    }

    // Sets up text field for entering name of root object to browse.
    JTextField rootField;
    Component createRootField(String initValue) {

	// Initialize search filter field with previous search filter
        rootField = new JTextField();
        rootField.setPreferredSize(new Dimension(50, 25));
        rootField.setMaximumSize(new Dimension(Short.MAX_VALUE, 25));
	rootField.setFont(Browser.largeTextFont);
	rootField.setEditable(true);
        rootField.setText(initValue);
	rootField.setToolTipText("enter name of root");
	//	rootField.setBackground(Color.white);
	rootField.addActionListener(new RootAction());

	// Add filter field to titled panel
        JPanel titlePanel = new JPanel(new BorderLayout());
	titlePanel.setBorder(BorderFactory.createTitledBorder("Root"));
        titlePanel.add(rootField, BorderLayout.CENTER);

	JPanel p = new JPanel(new BorderLayout());
	p.add(titlePanel, BorderLayout.CENTER);
	p.add(Box.createRigidArea(new Dimension(10, 10)), BorderLayout.SOUTH);

	return p;
    }

    // For now, only one listener is allowed
    void addConfigListener(ConfigListener listener) {
	this.listener = listener;
    }

    // Buttons for performing updates
    JButton add, remove, apply, dismiss, reload;

    // Create row of control buttons
    JPanel createButtonPanel() {
	GridLayout layout = new GridLayout(1, 5);
	layout.setHgap(5); 	// minimum horizontal gap of 5

	// Create panel to hold buttons
	JPanel panel = new JPanel(layout);

	// Create and add buttons
	panel.add(add = new JButton("Add"));
	panel.add(remove = new JButton("Remove"));
	panel.add(apply = new JButton("Apply"));
	panel.add(dismiss = new JButton("Dismiss"));
	panel.add(reload = new JButton("Reload"));

	apply.setEnabled(false); // disable until a change is made

	// Add tooltips to buttons
	add.setToolTipText("add line for entering new property");
	remove.setToolTipText("removed selected properties");
	apply.setToolTipText("reload browser using these attributes");
	dismiss.setToolTipText("dismiss window");
	reload.setToolTipText("reset properties to their original values");

	// Add listener for each button
	dismiss.addActionListener(new DismissActionHandler());
	add.addActionListener(new AddActionHandler());
	remove.addActionListener(new RemoveActionHandler());
	apply.addActionListener(new ApplyActionHandler());
	reload.addActionListener(new ReloadActionHandler());

	return panel;
    }

    // hit ENTER in root field
    class RootAction implements ActionListener {
	public void actionPerformed(ActionEvent evt) {
	    // Root has changed, so enable Apply button
	    apply.setEnabled(true);
	}
    }

    // Add a blank line for entering a new property
    class AddActionHandler implements ActionListener {
	public void actionPerformed(ActionEvent evt) {
	    // Create new row in table
	    int where = tableModel.addEmptyRow();

	    // Notify table of change
	    table.tableChanged(new TableModelEvent(tableModel,
		where, where, TableModelEvent.ALL_COLUMNS, 
		TableModelEvent.INSERT));

	    // Apply button now can be used
	    apply.setEnabled(true);
	}
    }

    // Remove a property
    class RemoveActionHandler implements ActionListener {
	public void actionPerformed(ActionEvent evt) {

	    // Remove selected row
	    int[] where = tableModel.removeRows();
	    if (where.length == 0) {
		// if none selected/removed, do nothing
		return;
	    }

	    // Notify table of change
	    table.tableChanged(new TableModelEvent(tableModel,
		where[0], where[where.length-1], 
		TableModelEvent.ALL_COLUMNS, 
		TableModelEvent.DELETE));

	    // Apply button now can be used
	    apply.setEnabled(true);
	}
    }

    // Apply changes
    class ApplyActionHandler implements ActionListener {
	public void actionPerformed(ActionEvent evt) {
	    if (listener != null) {
		// Notify listener of update after 
		listener.configurationUpdated(rootField.getText(),
		    tableModel.toHashtable());
	    }

	    // Dispose of "Configure" window
	    // ConfigDialog.this.dispose();
	}
    }

    // Get rid of window
    class DismissActionHandler implements ActionListener {
	public void actionPerformed(ActionEvent evt) {
	    // Get rid of window
	    ConfigDialog.this.dispose();
	}
    }

    // Refresh list with original data
    class ReloadActionHandler implements ActionListener {
	public void actionPerformed(ActionEvent evt) {
	    // Forget about any edits, revert to original.

	    rootField.setText(origRoot);

	    // Replace data
	    tableModel = new EnvTableModel(origEnv);
	    table.setModel(tableModel);

	    // Notify table of change
	    table.tableChanged(new TableModelEvent(tableModel));

	    // Disable Apply button (no change yet)
	    apply.setEnabled(false);
	}
    }

    // List of JNDI environment properties that can be gotten 
    // from System/ properties.
    static final String[] sysProps = {
	Context.INITIAL_CONTEXT_FACTORY,
	Context.OBJECT_FACTORIES,
	Context.PROVIDER_URL,
	Context.URL_PKG_PREFIXES,
	Context.DNS_URL};

    /**
     * Data model that holds property names and values.
     * Data is stored in two vectors, one for property names and
     * one for property values. 
     */
    class EnvTableModel extends AbstractTableModel {
	Vector names, values;

	EnvTableModel(Hashtable ht) {
	    toVectors(ht);
	}

	// Convert environment properties  into two vectors (names and values)
	void toVectors(Hashtable ht) {
	    if (ht == null || ht.size() == 0) {
		names = new Vector(10);
		values = new Vector(10);
		fillInFromSystem(ht);
		return;
	    }

	    names = new Vector(ht.size());
	    values = new Vector(ht.size());
	    Object name, value;
	    for (Enumeration enum = ht.keys();
		 enum.hasMoreElements();) {
		name = enum.nextElement();
		value = ht.get(name);
		names.addElement(name);
		values.addElement(value);
	    }
	    fillInFromSystem(ht);
	}

	// Fill in system properties if they're defined.
	void fillInFromSystem(Hashtable ht) {
	    for (int i = 0; i < sysProps.length; i++) {
		if (ht != null && ht.get(sysProps[i]) != null)
		    continue; // already there, don't override

		try {
		    String val = System.getProperty(sysProps[i]);
		    if (val != null) {
			names.addElement(sysProps[i]);
			values.addElement(val);
		    }
		} catch (SecurityException e) {} // ignore
	    }
	}

	// Convert table model (two vectors) into a Hashtable
	Hashtable toHashtable() {
	    int count = names.size();
	    Hashtable ht = new Hashtable(count+count+1);

	    Object name, value;
	    for (int i = 0; i < count; i++) {
		name = names.elementAt(i);
		value = values.elementAt(i);
		ht.put(name, value);
	    }
	    return ht;
	}

	// Number of columns is 2
	public int getColumnCount() { 
	    return heading.length; 
	}

	// Number of rows is number of properties
	public int getRowCount() { 
	    return names.size();
	}

	// Returns value of cell(row,col)
	public Object getValueAt(int row, int col) {
	    if (col == 0) {
		// property name
		return names.elementAt(row);
	    } else {
		// property value
		return values.elementAt(row);
	    }
	}

	public String getColumnName(int column) {
	    return heading[column];
	}

	// All properties are changeable
	public boolean isCellEditable(int row, int col) {
	    return true;
	}

	// Updates property name or value
	public void setValueAt(Object aValue, int row, int col) {
	    if (col == 0) {
		// Modifying property name
		names.setElementAt(aValue, row);
	    } else {
		// Modifying property value
		values.setElementAt(aValue, row);
	    }
	    apply.setEnabled(true);
	}

	// Add an empty row for entering property name/value pair
	public int addEmptyRow() {
	    names.addElement("");
	    values.addElement("");
	    return names.size() - 1 ;
	}

	// Removed selected rows
	public int[] removeRows() {
	    // Before removal, stop editing
	    table.editingStopped(new ChangeEvent(table));

	    int[] selected = table.getSelectedRows();
	    // returned array is always ordered
	    // from lowest to highest index

	    // start from back so deletions do not change indices
	    // (deleting an element from a Vector shifts the indices)
	    for (int i = selected.length-1; i >= 0; i--) {
		if (debug) {
		    System.err.println("removing " + selected[i] + ":" + 
			names.elementAt(selected[i]));
		}
		names.removeElementAt(selected[i]);
		values.removeElementAt(selected[i]);
	    }
	    return selected;
	}
    } 
}
