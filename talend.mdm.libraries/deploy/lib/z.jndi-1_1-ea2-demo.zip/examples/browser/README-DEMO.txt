		JNDI Demo Browser Release Notes
			Feb 11, 1998


This is a demo program for browsing and editing namespaces and
directories.  Documentation is available in the accompanying
readme.html file (in the examples/browser directory).


COPYRIGHT & DISCLAIMER

 * Copyright (c) 1998-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies.
 * 
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.

The JNDI logo and JNDI image that accompany this demo cannot be used
in any other context without the express written permission of Sun
Microsystems.

CHANGES SINCE PREVIOUS RELEASE (May 8, 1998)

- Use Swing 1.1 (or Swing that's in JDK1.2). [javax.swing]


RELEASE INFORMATION

This release contains:

lib/jndibrowser.jar
	class files and images for the demo browser.

examples/browser
	source files and images for the demo browser.

This release works with the JNDI1.1 release.

To run this demo, modify the runnit (or "runnit.bat" on Windows) file
according to the JDK/Swing software, the service providers and
naming/directory servers that you will be using.  

You can also run this demo as an applet inside a Web Browser.  The Web
Browser must support Swing1.1. You must also modify browser.html
accordingly.


SUPPORT INFORMATION

This demo browser and its source are being released without any
support.  We hope that you will find the software useful in learning
JNDI. Feel free to add features or fix bugs and share those changes
with others (the public mailing list for JNDI is
jndi-interest@java.sun.com).  Problems related to this demo software
can be reported to jndi@java.sun.com but because the product is
unsupported, you might not get any response.
