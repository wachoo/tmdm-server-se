/*
 * Copyright (c) 1998 Sun Microsystems, Inc. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * "@(#)SchemaDialog.java	1.1	99/05/06 SMI"
 */

package examples.browser;

import javax.swing.*;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.BorderLayout;
import java.awt.Component;
import java.util.Hashtable;

import javax.naming.directory.*;
import javax.naming.*;

/**
 * This class creates a window for viewing and editing the schema.
 * The window resembles the original browser panel and you can
 * perform the naming and directory operations on it just as you
 * can with the browser panel.
 *
 * @author Rosanna Lee
 */

class SchemaDialog extends JFrame {

    SchemaDialog(DirContext root, String rootName, Hashtable env) {
	super("Schema of '" + rootName + "'");

	// Add schema panel to frame
	SchemaPanel panel = new SchemaPanel(this, root, env);
	getContentPane().add(panel, BorderLayout.CENTER);
	panel.init();

	// Ensures that frame will be destroyed
	addWindowListener( new WindowAdapter() {
	    public void windowClosing(WindowEvent e) {
		dispose();}} );

	// make visible
	pack();
	show();
    }

    /**
     * This class uses most of DirPanel, except 
     * 1. Overrides getInitialContext() to return root of schema
     * 2. disables Configure button.
     */
    class SchemaPanel extends DirPanel {
	DirContext schemaRoot;

	SchemaPanel(Component cursorComp, DirContext root, Hashtable env) {
	    super(cursorComp, env, null);

	    // root of this panel is schemaRoot
	    schemaRoot = root;

	    // Cannot reinitialize namespace
	    configButton.setEnabled(false);
	}

	// For a schema tree, the "initial context" is the root
	// node with which the panel was created.
	Context getInitialContext() throws NamingException {
	    return schemaRoot;
	}
    }
}
