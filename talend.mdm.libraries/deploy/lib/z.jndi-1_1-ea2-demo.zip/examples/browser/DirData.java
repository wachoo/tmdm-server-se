/*
 * Copyright (c) 1998 Sun Microsystems, Inc. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * "@(#)DirData.java	1.1	99/05/06 SMI"
 */

package examples.browser;

import javax.naming.*;
import javax.naming.directory.*;

/**
  * This class represents a node in the directory tree. 
  * It subclasses SearchResult to override the toString() method
  * so that it returns the node name instead of of the contents
  * of SearchResult. It also provides a method isContext() for
  * determining whether the object in the binding is a context.
  *
  * @author Rosanna Lee
  */

public class DirData extends SearchResult {
    boolean checkedAlready = false;
    boolean isContext;

    boolean setContextFlag(boolean f) {
	checkedAlready = true;
	return (isContext=f);
    }

    void resetContextFlag() {
	checkedAlready = false;
    }

    public DirData(String name, String className) {
	super(name, className, null, null);
    }

    public DirData(String name, Object obj) {
	super(name, null, obj, null);
    }

    public DirData(String name, Object obj, Attributes attrs) {
	super(name, null, obj, attrs);
    }

    public DirData(String name, String className, Object obj, Attributes attrs) {
	super(name, className, obj, attrs);
    }

    /**
     * Determines whether the object in this binding is a context.
     * If the object is already available, check it.
     * Otherwise, use the class name of the object to check.
     */
    public boolean isContext() {
	if (checkedAlready) {
	    return isContext;
	}

	// If we have access to object, 
	if (getObject() instanceof Context) {
	    return setContextFlag(true);
	}

	String cname = getClassName();
	if (cname == null) {
	    return setContextFlag(false);
	} 

	// If classname indicates that it is a context, return true
	if (cname.equals("javax.naming.Context") ||
	    cname.equals("javax.naming.directory.DirContext")) {
	    return setContextFlag(true);
	}

	// use cname and reflection to determine if it is context
	try {
	    Class c = Class.forName(cname);
	    return setContextFlag(Context.class.isAssignableFrom(c));
	} catch (ClassNotFoundException e) {
	}
	return setContextFlag(false); // can't find out
    }

    public String toString() {
	return getName();
    }
}
