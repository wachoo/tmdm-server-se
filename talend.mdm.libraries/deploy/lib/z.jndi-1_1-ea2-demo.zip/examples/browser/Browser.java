/*
 * Copyright (c) 1998 Sun Microsystems, Inc. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * "@(#)Browser.java	1.1	99/05/06 SMI"
 */

package examples.browser;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.*;
import java.applet.Applet;
import java.net.URL;
import java.net.MalformedURLException;
import java.util.Hashtable;
import java.util.StringTokenizer;
import java.util.NoSuchElementException;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import javax.naming.*;

/**
  * This is the main program that starts up the browser.
  * It parses the command line arguments and creates the tabbed 
  * panels.
  *
  * usage: java examples.browser.Browser config1 config2 ...
  *
  * where configN is a string containing configuration for the N'th
  * tabbed panel. Each string is a '|'-separated string containing
  * environment properties for initializing the panel. See readme.html
  * for details.
  *
  * @author Rosanna Lee
  */

public class Browser extends JPanel {
    // Directory prefix of where to find files associated with browser
    final static String BROWSER_DIR = "examples/browser/";
    // Directory prefix of where to find images
    final static String IMAGE_DIR = BROWSER_DIR + "images/";

    // Font for entering text
    final static Font largeTextFont = new Font("Monospaced", Font.PLAIN, 18);

    // Used for loading resources
    static Browser browser;

    // Used for loading resources
    Applet applet = null;

    // Used for console;
    static JTextArea console = new JTextArea();

    // Images for front panel
    ImageIcon jndiDuke, jndiLogo;
    static ImageIcon speakerIcon;

    // Front panel
    JPanel frontPanel;

    // Tab labels for service providers
    String[] tabLabel;

    // Panels for service provider
    DirPanel[] spPanel;

    // Environment properties for each provider
    Hashtable[] env;

    // Root to start browsing for each provider
    String[] root;

    // Tabbed pane that contains the front and service provider panels.
    JTabbedPane tabbedPane;

    // Component for setting curosr
    Component cursorComp;

    // %%% currently we don't do anything with the applet
    public Browser(Component cursorComp, String[] args) {
	super(new BorderLayout());

	this.cursorComp = cursorComp;

	if (cursorComp instanceof Applet) {
	    applet = (Applet)cursorComp;
	}

	setUpEnvironment(args);

	loadImages();

	browser = this;

	console.setEditable(false);

	// Create a tab pane
	tabbedPane = new JTabbedPane();

	// Create front panel
	frontPanel = constructFrontPanel();
	tabbedPane.addTab("", jndiLogo, frontPanel);
	tabbedPane.setSelectedIndex(0);

	// Add provider panels
	for (int i = 0; i < spPanel.length; i++) {
	    spPanel[i] = new DirPanel(cursorComp, env[i], root[i]);
	    tabbedPane.addTab(tabLabel[i], null, spPanel[i]);
	}

	// Add Tab change listener
        tabbedPane.addChangeListener(new TabbedPaneSwitcher());
        
	add(tabbedPane, BorderLayout.CENTER);
    }

    /**
     * Loads all images used by browser's front page.
     */
    void loadImages() {
	jndiDuke = loadImageIcon("dukeWithTitle.gif", "Duke and Title");
	jndiLogo = loadImageIcon("jndiLabelSmall.gif", "Small JNDI Label");

	speakerIcon = loadImageIcon("speaker.gif", "Speaker Icon");
    }

    /**
     * Constructs front panel (page) of browser.
     */
    JPanel constructFrontPanel() {
	Border emptyBorder0 = new EmptyBorder(50, 50, 50, 50);
	JPanel page = new JPanel(new BorderLayout());

	JLabel l = new JLabel(jndiDuke);
	l.setBorder(emptyBorder0);
	page.add(l, BorderLayout.CENTER);

	return page;
    }

    Hashtable iconCache = new Hashtable(17);

    /**
      * Helper routine for loading in image for appplication or applet.
      */

    URL getResource(String filename) {
	URL url;
	ClassLoader cl = this.getClass().getClassLoader();
	if (cl == null)
	    url = ClassLoader.getSystemResource(filename);
	else
	    url = cl.getResource(filename);

	if (url == null && applet != null) {
	    try {
		url = new URL(applet.getCodeBase(), filename);
	    } catch(MalformedURLException e) {
		System.err.println("Error trying to construct URL for " + filename);
	    }
	}
	return url;
    }

    public ImageIcon loadImageIcon(String filename, String description) {
	ImageIcon icon = (ImageIcon)iconCache.get(filename);
	if (icon != null) {
	    return icon;
	}

	URL url = getResource(IMAGE_DIR+filename);
	if (url == null) {
	    System.err.println("No image for " + filename);
	    return null;
	}

	icon = new ImageIcon(url, description);
	iconCache.put(filename, icon);
	return icon;
    }

    private void setUpEnvironment(String[] args) {
	// Last one is always custom
	tabLabel = new String[args.length+1];
	spPanel = new DirPanel[args.length+1];
	env = new Hashtable[args.length+1];
	root = new String[args.length+1];

	for (int i = 0; i < args.length; i++) {
	    // Each argument is of the form
	    // label|factoryclass|url|root|auth|principal|password
	    StringTokenizer parser = new StringTokenizer(args[i], "|");
	    tabLabel[i] = parser.nextToken();
	    env[i] = new Hashtable(11);

	    try {
		env[i].put(Context.INITIAL_CONTEXT_FACTORY, parser.nextToken());
		env[i].put(Context.PROVIDER_URL, parser.nextToken());
		root[i] = parser.nextToken();
		env[i].put(Context.SECURITY_AUTHENTICATION, parser.nextToken());
		env[i].put(Context.SECURITY_PRINCIPAL, parser.nextToken());
		env[i].put(Context.SECURITY_CREDENTIALS, parser.nextToken());
	    } catch (NoSuchElementException e) {
		// No more
	    }
	}

	// Set up custom
	tabLabel[args.length] = "Generic";
	env[args.length] = null;
    }

    /**
     * Tab Listener; switches between tabbed panels
     */
    class TabbedPaneSwitcher implements ChangeListener {
	public void stateChanged(ChangeEvent e) {
	    waitCursor();
	    JTabbedPane tab = (JTabbedPane) e.getSource();
	    int index = tab.getSelectedIndex();
	    Component currentPanel = tab.getComponentAt(index);

	    // Enable/disable edit menu and configure button
	    //	    editMenu.setEnabled(currentPanel != frontPanel);

	    if (currentPanel != frontPanel) {
		((DirPanel)currentPanel).init();
	    }
	    restoreCursor();
	}
    }

    /**
     * Methods for managing stop watch cursor.
     */
    Cursor savedCursor;
    void waitCursor() {
	savedCursor = cursorComp.getCursor();
	cursorComp.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
    }

    void restoreCursor() {
	cursorComp.setCursor(savedCursor);
    }

    /**
     * Methods for managing stack traces that are displayed in console.
     */
    static void appendToConsole(Exception e) {
	ByteArrayOutputStream str = new ByteArrayOutputStream();
	PrintStream pr = new PrintStream(str);
	e.printStackTrace(pr);
	pr.flush();
	synchronized (console) {
	    console.append(str.toString());
	}
    }

    static void clearConsole() {
	synchronized(console) {
	    console.setText("");
	}
    }

    /**
     * Starts browser up as an application.
     */
    static public void main(String args[]) {
	JFrame frame = new JFrame("JNDI Browser");
	frame.getContentPane().setLayout(new BorderLayout());
	frame.getContentPane().add(new Browser(frame, args), BorderLayout.CENTER);

	// For terminating program, should not do this for applet
	frame.addWindowListener( new WindowAdapter() {
	    public void windowClosing(WindowEvent e) {
		System.exit(0);}});

	frame.pack();
	frame.show();
    }
}
