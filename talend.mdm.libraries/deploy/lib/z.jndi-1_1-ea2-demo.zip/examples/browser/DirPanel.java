/*
 * Copyright (c) 1998 Sun Microsystems, Inc. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * "@(#)DirPanel.java	1.1	99/05/06 SMI"
 */

package examples.browser;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

import javax.swing.tree.*;

import javax.naming.*;
import javax.naming.directory.*;
import java.util.Enumeration;
import java.util.Hashtable;
import java.net.URL;

/**
  * This class is a panel for displaying a namespace.
  * It consists of a toolbar, a split pane and a status line at the bottom.
  * The left pane contains a tree showing the hierarchical structure
  * of the namespace. The right pane is a list displaying the contents
  * of the selected tree node and search results.
  *
  * Double clicking on a list entry brings up a window for viewing and
  * editing the attributes associated with the entry.
  *
  * @author Rosanna Lee
  */

public class DirPanel extends JPanel implements ConfigListener { 
    static final boolean debug = true;

    JTree tree;  	// Hierarchical view of the namespace
    JList list;		// Contents of the selected tree node
    DirTreeModel treeModel; // Representation of data in tree
    JViewport treeViewPort;
    JLabel status = new JLabel("Ready");
    
    Hashtable env;	// Environment properties of provider
    String root;	// Root of namespace to start browsing

    boolean initialized = false;  // whether panel's data has been initialized

    Component cursorComp; // Component for setting cursor

    /**
      * Constructs a new instance of DirPanel.
      * More arguments to come: Environment properties
      */
    public DirPanel(Component cursorComp, Hashtable env, String rootName) {
	super(new BorderLayout());

	this.cursorComp = cursorComp;
	this.env = env;
	this.root = rootName;

	list = new JList(new DefaultListModel());
	list.setCellRenderer(new DirListCellRenderer());

	list.addMouseListener(new DoubleClickHandler());

// -- Put tree and list into scrollers and SplitPane

	// Set up empty tree for now; see initialize()
	tree = new JTree(new Hashtable(7));
	tree.setShowsRootHandles(true);
	tree.collapseRow(0);

	/* Put the tree in a scroller. */
	JScrollPane leftSp = new JScrollPane();
	leftSp.setPreferredSize(new Dimension(250, 300));
	treeViewPort = leftSp.getViewport();
	treeViewPort.setView(tree);

	/* Put list in a scroller */
	JScrollPane rightSp = new JScrollPane();

	rightSp.setPreferredSize(new Dimension(250, 300));
	rightSp.getViewport().setView(list);

	JSplitPane splitPane
	    = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftSp, rightSp);
	splitPane.setPreferredSize(new Dimension(500, 300));
	splitPane.setContinuousLayout(true); 

	/* Put split pane into panel, and add status line on bottom */
	add(constructToolBar(), BorderLayout.NORTH);
	add(splitPane, BorderLayout.CENTER);
	add(status, BorderLayout.SOUTH);
    }

// --- set up tree

    void init() {
	if (initialized) return;

	DirTreeNode rootNode = null;
	waitCursor();
	try {
	    Context ctx = getInitialContext();
	    Object obj;
	    
	    if (root != null) {
		obj = ctx.lookup(root);
		rootNode = new DirTreeNode(new DirData(root, obj));
	    } else {
		rootNode = new DirTreeNode(new DirData("", ctx));
	    }
	} catch (NamingException e) {
	    if (debug) e.printStackTrace();
	    setStatus(e);
	    return;
	} finally {
	    restoreCursor();
	}

	initialized = true;

	/* Create the tree. */
	tree = new JTree(rootNode);
	tree.setShowsRootHandles(true);
	tree.collapseRow(0);

	treeModel = new DirTreeModel(rootNode);
	tree.setModel(treeModel);

	/* Allow items to be editable (renamed) */
	tree.setEditable(true);

	/* Enable tool tips for the tree, without this tool tips will not
	   be picked up. */
	ToolTipManager.sharedInstance().registerComponent(tree);

	/* Make the tree use an instance of DirTreeCellRenderer for
	   drawing nodes. */
	tree.setCellRenderer(new DirTreeCellRenderer());

	/* Make tree ask for the height of each row. */
	tree.setRowHeight(-1);

	/* Add listeners for selection and expansion of nodes */
	tree.addTreeSelectionListener(new TreeSelectionHandler());
	//	tree.addTreeExpansionListener(new TreeExpansionHandler());

	/* Update view port in split pane. */
	treeViewPort.setView(tree);
    }

    /**
     * Called when root and/or environment properties have been modified.
     * Force reset of tree and list views.
     */
    void reinitialize(String newRoot, Hashtable newEnv) {
	if (debug) System.err.println("Reinitializing");

	this.root = newRoot;
	this.env = newEnv;

	// initialize tree
	gotten = false;
	initialized = false;
	init();  	

	// initialize list
	DefaultListModel lm = (DefaultListModel)list.getModel();
	lm.clear();

	// Force frame to update
	invalidate();
	validate();
    }

// -- Deal with Initial Context

    Context initialContext = null;
    boolean gotten = false;

    Context getInitialContext() throws NamingException {
	if (gotten) {
	    return initialContext;
	}
	initialContext = new InitialDirContext(env);
	gotten = true;
	return initialContext;
    }

    Context getParentContext(DirTreeNode node) throws NamingException {
	DirTreeNode parent = (DirTreeNode)node.getParent();
	Context parentCtx = null;

	if (parent != null) {
	    parentCtx = (Context)((DirData)parent.getUserObject()).getObject();
	}
	if (parentCtx == null) {
	    // we're at the root, parent is the initial context
	    parentCtx = getInitialContext();
	}
	return parentCtx;
    }

// -- Methods for dealing with status line

    void setStatus(String s, boolean beep) {
	if (beep) 
	    java.awt.Toolkit.getDefaultToolkit().beep();
	if (debug) System.err.println("status: " + s);
	status.setText(s);
    }

    void setStatus(String s) {
	setStatus(s, true);
    }

    void setStatus(Exception e) {
	// %%% for DEMO only
	boolean beep =  !(e instanceof NoInitialContextException);
	setStatus(e.getClass().getName(), beep);
	Browser.appendToConsole(e);
    }

    void resetStatus() {
	status.setText("Ready");
    }

// -- Methods for setting stop watch cursor

    Cursor savedCursor;
    void waitCursor() {
	//System.err.println("set wait cursor");
	savedCursor = cursorComp.getCursor();
	cursorComp.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
    }

    void restoreCursor() {
	//System.err.println("restoring cursor");
	cursorComp.setCursor(savedCursor);
    }

    /**
      * Returns the TreeNode instance that is selected in the tree.
      * If nothing is selected, null is returned.
      */
    DefaultMutableTreeNode getSelectedNode() {
	TreePath   selPath = tree.getSelectionPath();

	if(selPath != null)
	    return (DefaultMutableTreeNode)selPath.getLastPathComponent();
	return null;
    }

    /**
     * Ask user whether it is OK to proceed.
     */
    boolean checkWithUser(String msg) {
	Object[] options = {"OK", "CANCEL"};
	return (JOptionPane.showOptionDialog(this, msg, "Warning",
		   JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE,
                   null, options, options[1]) == 0);
    }

    /**
      * RemoveAction removes the selected node from the tree. 
      * If the root is selcted or if nothing is selected, nothing is removed.
      */
    void removeSelectedNode() {
	DirTreeNode target = (DirTreeNode)getSelectedNode();

	if (target == (DirTreeNode)treeModel.getRoot()) {
	    setStatus("Cannot remove root");
	    return;
	}

	if(target == null) {
	    setStatus("Select a tree node first.");
	    return;
	}

	try {
	    Context parentCtx = getParentContext(target);
	    String name = ((DirData)target.getUserObject()).getName();

	    if (!checkWithUser(
		"Click OK to remove '" + name + "'")) {
		return;
	    }
	    waitCursor();

DirPanel.debugName("Remove", name);
	    if (((DirData)target.getUserObject()).isContext()) {
		parentCtx.destroySubcontext(name);
	    } else {
		parentCtx.unbind(name);
	    }
	    treeModel.removeNodeFromParent(target);
	    resetStatus();
	} catch (NamingException e) {
	    if (debug) e.printStackTrace();
	    setStatus(e);
	} finally {
	    restoreCursor();
	}
    }

    /**
     * When tree node is selected, display its contents in list.
     */
    class TreeSelectionHandler implements TreeSelectionListener {

	public void valueChanged(TreeSelectionEvent evt) {
	    DirTreeNode target;
	    DefaultListModel lm;

	    // Only do something if node is selected
	    // Ignore if unselected
	    if (!evt.isAddedPath()) {
		return;
	    }

	    waitCursor();

	    try {
		target = (DirTreeNode)evt.getPath().getLastPathComponent();
		lm = (DefaultListModel)list.getModel();
		lm.clear();
		if (target.loadChildren(false)) {
		    for (Enumeration enum = target.children();
			 enum.hasMoreElements();) {
			lm.addElement(enum.nextElement());
		    }
		} else {
		    /**
		      * If object is not a context, then display its contents
		      */
		    DirData data = (DirData)(target.getUserObject());
		    if (data.getObject() != null) {
			if (data.getObject() instanceof Component) {
			    (new ShowComponentThread(
				(Component)data.getObject(),
				data.getName())).start();
			} else if (!(data.getObject() instanceof Context)) {
			    (new ShowComponentThread(
				data.getObject().toString(),
				data.getName())).start();
			}
		    }
		}
		// Refresh list area
		list.invalidate();
		list.validate();
	    } finally {
		restoreCursor();
	    }
    }
    }

    class ShowComponentThread extends Thread {
	Object obj;
	String name;

	ShowComponentThread(Object obj, String name) {
	    this.obj = obj;
	    this.name = name;
	}
	public void run() {
	    JOptionPane.showMessageDialog(null, obj, name,
		JOptionPane.PLAIN_MESSAGE);

	    // The following shows a "Dismiss" button instead of "OK"
/*	    String[] options = {"Dismiss"};
	    JOptionPane.showOptionDialog(null,
		component,
		name, JOptionPane.PLAIN_MESSAGE, JOptionPane.PLAIN_MESSAGE,
		null, options, options[0]);
*/
	}
    }

    /**
     * When tree node is opened, load its contents.
     */
/*
    class TreeExpansionHandler implements TreeExpansionListener,
    	LoadChildrenListener {
	public void treeExpanded(TreeExpansionEvent evt) {
	    waitCursor();
	    DirTreeNode target = 
		(DirTreeNode)evt.getPath().getLastPathComponent();
	    target.loadChildren(false);
	}

	public void loadCompleted(boolean ok) {
	    if (ok) {
		resetStatus();
	    }
	    restoreCursor();
	}

	public void treeCollapsed(TreeExpansionEvent evt) {
	    resetStatus();   // Reset status line
	}
    }
*/

    /**
     * Double-clicking on a list item displays its attributes.
     */
    class DoubleClickHandler extends MouseAdapter {
	public void mouseClicked(MouseEvent evt) {
	    if (evt.getClickCount() == 2) {
		int index = list.locationToIndex(evt.getPoint());
		ListModel lm = list.getModel();
		DirTreeNode target = (DirTreeNode)lm.getElementAt(index);
		showAttributes(target);
	    }
	}
    }

    /**
     * Creates the toolbar.
     */
    JButton configButton;
    JToolBar constructToolBar() {
	JToolBar toolBar = new JToolBar();
	// eliminate 
	toolBar.setMargin(new Insets(0, 0, 0, 0));

	addTool(toolBar, "class", "Class", new ShowClassAction(),
	    "show class");
	addTool(toolBar, "attributes", "Attributes", new ShowAttributesAction(),
	    "show attributes");
	addTool(toolBar, "search", "Search", new SearchAction(),
	    "perform search");
	addTool(toolBar, "schema", "Schema", new SchemaAction(),
	    "get schema");

	toolBar.addSeparator();
	addTool(toolBar, "new", "New", new CreateChildAction(), 
	    "create new child"); 
	addTool(toolBar, "remove", "Remove", new RemoveAction(), 
	    "remove selected node");

	toolBar.addSeparator();

	addTool(toolBar, "reload", "Reload", new ReloadAction(), 
	    "reload selected node");
	configButton = 
	    addTool(toolBar, "configure", "Configure", new ConfigAction(), 
	    "configure root and environment properties");
	addTool(toolBar, "console", "Console", new ConsoleAction(),
	    "display console window");
	addTool(toolBar, "help", "Help", new HelpAction(), "how to use browser");

	return toolBar;
    }

    /**
     * Adds an item to the toolbar.
     */
    void addTool(JToolBar toolBar, String name, String label, ActionListener act) {
	addTool(toolBar, name, label, act, name);
    }

    /**
     * Adds an item to the toolbar.
     */
    JButton addTool(JToolBar toolBar, String name, String label,  
	ActionListener act, String tooltip) {

	JButton b = (JButton) toolBar.add(
	    new JButton(
		Browser.browser.loadImageIcon(name + ".gif", tooltip)));
	b.setHorizontalTextPosition(AbstractButton.CENTER);
	b.setVerticalTextPosition(AbstractButton.BOTTOM);
	b.setToolTipText(tooltip);
	if (act != null)
	    b.addActionListener(act);

	return b;
    }

    /**
      * Show attributes of currently selected list node.
      */
    class ShowAttributesAction implements ActionListener {
	public void actionPerformed(ActionEvent evt) {
	    ListModel lm = list.getModel();
	    int target = list.getSelectedIndex();
	    if (target >= 0) {
		showAttributes((DirTreeNode)lm.getElementAt(target));
		return;
	    }

	    // no item in list is selected, try selected tree node
	    DirTreeNode node = (DirTreeNode)getSelectedNode();
	    if (node != null) {
		showAttributes(node);
	    } else {
		setStatus("Select an item in tree or list first.");
	    }
	}
    }

    /**
     * Moves component (x,y) relative to top-left corner of this panel.
     */
    void moveWindow(Component c) {
	Point pt = getLocationOnScreen();
	Dimension dim = getSize();
	
	c.setLocation(pt.x+(dim.width/2), pt.y+(dim.height/2));
    }


    /**
      * Show attributes in 2-column table in a popup window.
      */
    void showAttributes(DirTreeNode target) {
	try {
	    waitCursor();
	    Context parentCtx = getParentContext(target);
	    if (parentCtx instanceof DirContext) {
		String name = 
		    ((DirData)(target.getUserObject())).getName();

DirPanel.debugName("Get Attributes", name);
		Attributes attrs = ((DirContext)parentCtx).getAttributes(name);
		moveWindow(new AttrDialog((DirContext)parentCtx, name, attrs));
	    } else {
		setStatus("Can only get attributes from DirContext");
	    }
	} catch (NamingException e) {
	    if (debug) e.printStackTrace();
	    setStatus(e);
	} finally {
	    restoreCursor();
	}
    }

    /**
      * Create new child for currently selected tree node.
      */
    class CreateChildAction implements ActionListener {
	public void actionPerformed(ActionEvent evt) {
	    DirTreeNode target = (DirTreeNode)getSelectedNode();

	    // If no node has been selected, return
	    if (target == null) {
		setStatus("Select an item in tree.");
		return;
	    }


	    // Can only create a child if node is a context
	    Object obj = ((DirData)target.getUserObject()).getObject();
	    if (!(obj instanceof Context)) {
		setStatus("A leaf cannot have a child.");
		return;
	    }

	    waitCursor();

	    // Get any attributes this node has and use as
	    // template for child.
	    Attributes attrs = null;
	    String name = 
		((DirData)(target.getUserObject())).getName();
	    try {
		Context parentCtx = getParentContext(target);
		if (parentCtx instanceof DirContext) {

DirPanel.debugName("Getting Attributes for Creating Child", name);
		    attrs = ((DirContext)parentCtx).getAttributes(name);
		}
	    } catch (NamingException e) {} // ignore

	    // Create frame 
	    CreateDialog d = 
		new CreateDialog((Context)obj, name, attrs);
	    moveWindow(d);
	    d.addCreateListener(new CreateResultAction(target));
	    restoreCursor();
	}
    }

    /**
     * Action handler for updating tree view when node has been created
     */
    class CreateResultAction implements CreateListener {
	DirTreeNode parentNode;

	public CreateResultAction(DirTreeNode n) {
	    parentNode = n;
	}

	// Invoked to update tree and list views when a new node has been created
	public void objectCreated(String name, Context obj, Attributes attrs) {
	    // %%% Currently nothing is done about attrs
	    DirTreeNode child = new DirTreeNode(new DirData(name, obj, attrs));

	    // Update tree
	    treeModel.insertNodeInto(child, parentNode, 0);

	    // Update list
	    DefaultListModel lm = (DefaultListModel)list.getModel();
	    lm.addElement(child);
	}
    }

    /**
     * Creates search window for specifying search.
     */
    class SearchAction implements ActionListener {
	public void actionPerformed(ActionEvent evt) {
	    // Search selected node
	    DirTreeNode target = (DirTreeNode)getSelectedNode();
	    if (target == null) {
		setStatus("Select a tree node first.");
		return;
	    }
	    try {
		waitCursor();
		Context parentCtx = getParentContext(target);
		if (parentCtx instanceof DirContext) {
		    // should pass status as param
		    SearchDialog s =
			new SearchDialog((DirContext)parentCtx, 
			    ((DirData)(target.getUserObject())).getName());
		    moveWindow(s);
		    s.addSearchListener(new SearchResultAction(target));
		} else {
		    setStatus("Can only search a DirContext");
		}
	    } catch (NamingException e) {
		if (debug) e.printStackTrace();
		setStatus(e);
	    } finally {
		restoreCursor();
	    }
	}
    }

    /**
     * Action Handler for updating display after search completes.
     */
    class SearchResultAction implements SearchListener {
	DirTreeNode parentNode;
	public SearchResultAction(DirTreeNode n) {
	    parentNode = n;
	}

	// Invoked to update the list view to display search results
	public void searchCompleted(NamingEnumeration results) {
	    DefaultListModel lm = (DefaultListModel)list.getModel();
	    lm.clear();

	    waitCursor();

	    try {
		while(results.hasMoreElements()) {
		    SearchResult r = (SearchResult)results.next();

		    DirTreeNode fakeNode = new DirTreeNode(new DirData(
			r.getName(), r.getClassName(), r.getObject(), 
			r.getAttributes()));
		    fakeNode.setParent(parentNode);
		    lm.addElement(fakeNode);
		}
		resetStatus();
	    } catch (NamingException e) {
		if (debug) e.printStackTrace();
		setStatus(e);
	    } finally {
		restoreCursor();
	    }

	    // Refresh list area
	    list.invalidate();
	    list.validate();
	}
    }
    
    // Invoked when environment properties have been changed
    public void configurationUpdated(String newRoot, Hashtable newEnv) {
	reinitialize(newRoot, newEnv);
    }

    // Create window for updating environment properties
    class ConfigAction implements ActionListener {
	public void actionPerformed(ActionEvent evt) {
	    waitCursor();

	    // Create frame for configuring environment properties
	    ConfigDialog config = new ConfigDialog(root, env);
	    moveWindow(config);

	    // Add self for receiving updates from frame
	    config.addConfigListener(DirPanel.this);

	    restoreCursor();
	}
    }

    // Create window for displaying console messages
    class ConsoleAction implements ActionListener {
	public void actionPerformed(ActionEvent evt) {
	    waitCursor();

	    moveWindow(new ConsoleDialog(Browser.console));

	    restoreCursor();
	}
    }


    // Create window for viewing schema of selected node
    class SchemaAction implements ActionListener {
	public void actionPerformed(ActionEvent evt) {
	    // Search selected node
	    DirTreeNode target = (DirTreeNode)getSelectedNode();
	    if (target == null) {
		setStatus("Select a tree node first.");
		return;
	    }
	    try {
		waitCursor();
		DirData data = (DirData)target.getUserObject();
		Object obj = data.getObject();

		if (!(obj instanceof DirContext)) {
		    setStatus("Can only get schema from a DirContext.");
		    return;
		}

		Context parentCtx = getParentContext(target);

		DirContext schema = ((DirContext)obj).getSchema("");
		if (schema == null) {
		    setStatus("No schema available for '" + 
			data.getName() + "'");
		    return;
		}

		moveWindow(new SchemaDialog(schema, data.getName(), env));
	    } catch (NamingException e) {
		if (debug) e.printStackTrace();
		setStatus(e);
	    } finally {
		restoreCursor();
	    }
	}
    }


    // Show class name of selected list or tree node
    class ShowClassAction implements ActionListener {
	public void actionPerformed(ActionEvent evt) {

	    DirTreeNode target;

	    // Try list first
	    ListModel lm = list.getModel();
	    int ind = list.getSelectedIndex();
	    if (ind > 0) {
		target = (DirTreeNode)lm.getElementAt(ind);
	    } else {

	    // Try tree
		target = (DirTreeNode)getSelectedNode();
		if (target == null) {
		    setStatus("Select a tree node first.");
		    return;
		}
	    }

	    JOptionPane.showMessageDialog(
		DirPanel.this, 
		((DirData)target.getUserObject()).getClassName(),
		"Class of '" + ((DirData)(target.getUserObject())).getName() +
		"'",
		JOptionPane.PLAIN_MESSAGE);
	}
    }

    class HelpAction implements ActionListener {
	public void actionPerformed(ActionEvent evt) {

	// Workaround for problem with URLs and HTML Editor.
	// This might not work inside an applet.
	// Workaround tries to get HREF's to work, gets further
	// but still doesn't work.
/*
	try {
	    File f = new File(filename);
	    url = new URL("file:" + f.getAbsolutePath());
	} catch (MalformedURLException e) {
	    System.out.println("Cannot open " + filename);
	    return;
	}
*/


// Note that the following generates URLs that the HTML Editor
// doesn't seem to understand. It causes it to generate HyperlinkEvents
// containing null URLs. But then, relative URLs don't
// seem to work anyways. 

	    URL url = Browser.browser.getResource(
		Browser.BROWSER_DIR + "readme.html");
	    if (url == null) {
		setStatus("Help file not found");
		return;
	    }
	    waitCursor();
	    moveWindow(new HelpDialog(url));
	    restoreCursor();
	}
    }

    /**
      * ReloadAction is used to reload from the selected node.  If nothing
      * is selected, reload is not issued.
      */
    class ReloadAction implements ActionListener {
	/**
	  * Reload starting from the selected node.  If nothing
	  * is selected, reload is not issued.
          *
          * Invoked when the user clicks on the Reload menu item.
          * Determines the selection from the Tree and asks the treemodel
          * to reload from that node.
          */
	public void actionPerformed(ActionEvent evt) {
	    DefaultMutableTreeNode target = getSelectedNode();

	    if(target != null) {
		waitCursor();
		treeModel.reload(target);
		restoreCursor();
	    } else
		setStatus("Select tree node to be reloaded first");
	}
    }

    /**
      * RemoveAction removes the selected node from the tree.  If
      * The root or nothing is selected nothing is removed.
      */
    class RemoveAction implements ActionListener {
	/**
	  * Removes the selected item as long as it isn't root.
	  */
	public void actionPerformed(ActionEvent evt) {
	    removeSelectedNode();
	}
    }

/**
  * DirTreeModel extends DefaultTreeModel to override valueForPathChanged().
  * This method is called as a result of the user editing the string name of
  * a node in the tree, which in turn results in the node being renamed in
  * the underlying namespace.
  *
  */

    public class DirTreeModel extends DefaultTreeModel {
    /**
      * Creates a new instance of DirTreeModel with newRoot set
      * to the root of this model.
      */
    public DirTreeModel(TreeNode newRoot) {
	super(newRoot);
    }

    public void reload(TreeNode node) {
	if (node != null) {
	    ((DirTreeNode)node).loadChildren(true);
	    super.reload(node);
	}
    }

    /**
     * Attempts to rename node as specified. If not successful, restore old name.
     */
    public void valueForPathChanged(TreePath path, Object newValue) {

	DirTreeNode target = (DirTreeNode)path.getLastPathComponent();
	if (((DirData)(target.getUserObject())).getName().equals(newValue)) {
	    // nothing has changed
	    return;
	}

	try {
	    Context parentCtx = getParentContext(target);

	    // Update namespace
	    String oldName = 
		((DirData)(target.getUserObject())).getName();

DirPanel.debugName("rename", oldName);
DirPanel.debugName("rename", (String)newValue);

	    if (debug) 
		System.err.println("renaming " + oldName + 
		    " to " + (String)newValue);

	    parentCtx.rename(oldName, (String)newValue);

	    // Update tree node
	    ((DirData)target.getUserObject()).setName((String)newValue);

	    // Update tree model
	    nodeChanged(target);

	    // Reset status 
	    resetStatus();
	} catch (NamingException e) {
	    // e.printStackTrace();
	    setStatus(e);
	}

    }
}

/**
  * This class represents a node in the namespace/directory.
  * It is modified from DynamicTreeNode in Swing's SampleTreeexample.
  *
  * Each DirTreeNode has a user object that is of class DirData.
  *
  */

public class DirTreeNode extends DefaultMutableTreeNode {
    boolean hasLoaded = false;

    /**
      * Constructs a new DirTreeNode instance with userObj as the user
      * object.
      */
    public DirTreeNode(Object userObj) {
	super(userObj);
    }

    /**
      * Determines whether this node is a leaf node.
      * A node is a leaf if it is not a context.
      * Overriding this seems to affect the display.
      * When not overridden, empty contexts are displayed as "dots".
      * When overridden as follows, empty contexts are displayed as folders.
      */
    public boolean isLeaf() {
	return !((DirData)getUserObject()).isContext();
    }

    /**
      * Determines whether this node can have children.
      * Only contexts can have children.
      */
    public boolean getAllowsChildren() {
	return ((DirData)getUserObject()).isContext();
    }

    /**
      * Loads the children of this node and return the number of children.
      *
      * If the children have not been loaded yet, use loadChildren()
      * to load the children before returning the number of children.
      */
    public int getChildCount() {
	loadChildren(false); // should be empty to start
	return super.getChildCount();
    }

    /**
      * Loads children from the naming/directory service by using list().
      *
      * This method is invoked the first time getChildCount() is called.
      * The list is then cached, so there might be slight inconsistencies
      * between the actual state of the namespace/directory and what is
      * shown.
      * If higher level of consistency is desired, then the list should
      * be refreshed (each time getChildCount()) is called but this
      * can be prohibitively costly.
      */
    boolean loadChildren(boolean force) {
	// If not forced to reload, and children have already
	// been loaded, return true.

	if (!force && hasLoaded) {
	    resetStatus();
	    return true;
	}
	waitCursor();

	DirData dirData = (DirData)getUserObject();
	String name = dirData.getName();
	Object obj = dirData.getObject();

	try {
	    if (obj == null) {
		// object not set yet, go and fetch it by
		// doing a lookup() in the parent context

		try {
		    Context parentCtx = getParentContext(DirTreeNode.this);

DirPanel.debugName("load children", name);
		    obj = parentCtx.lookup(name);
		} catch (NamingException e) {
		    // e.printStackTrace();
		    setStatus(e);
		    return hasLoaded = false;
		}

		// Update object stored in DirData with newly gathered info
		dirData.setObject(obj);
		dirData.resetContextFlag();
	    }

	    if (!(obj instanceof Context)) {
		setStatus(name + " is of class " + 
		    dirData.getClassName(), false);

		return hasLoaded = false;
	    }

	    DirData childData;
	    DirTreeNode childNode;
	    int counter = 0;

	    if (force) {
		removeAllChildren();
	    }

	    Context ctx = (Context)obj;
	    try {
		NamingEnumeration nl = ctx.list("");

		while (nl.hasMoreElements()) {
		    NameClassPair nc = (NameClassPair)nl.next();
		    childData = new DirData(nc.getName(), nc.getClassName());
		    childNode = new DirTreeNode(childData);
		    insert(childNode, counter++);
		}
		resetStatus();
		return hasLoaded = true;	
	    } catch (NamingException e) {
		// e.printStackTrace();
		setStatus(e);
		return hasLoaded = false;
	    }
	} finally {
	    restoreCursor();
	}
    }
}

/**
  * This class is used to draw a tree node.
  * 
  * @see DirIconMap
  */

    static Icon leafIcon = UIManager.getIcon("Tree.leafIcon");
    static Icon closedIcon =  UIManager.getIcon("Tree.closedIcon");
    static Icon openIcon = UIManager.getIcon("Tree.openIcon");

    class DirTreeCellRenderer extends JLabel implements TreeCellRenderer {
	DirTreeCellRenderer() {
	    setOpaque(true);
	}


    public Component getTreeCellRendererComponent(
	JTree tree,
	Object value,
	boolean isSelected,
	boolean isExpanded,
	boolean isLeaf,
	int row,
	boolean hasFocus) {

	String stringValue = tree.convertValueToText(value, isSelected,
	    isExpanded, isLeaf, row, hasFocus);
	setText(stringValue);

	DirTreeNode node = (DirTreeNode)value;
	DirData realObj = (DirData)node.getUserObject();
	String className = realObj.getClassName();

	Icon icon = DirIconMap.get(className, isExpanded);
	if (icon == null) {
	    if (isLeaf)
		icon = leafIcon;
	    else if (isExpanded)
		icon = openIcon;
	    else 
		icon = closedIcon;
	}
	setIcon(icon);

	if (isSelected) {
	    setForeground(list.getSelectionForeground());
	    setBackground(list.getSelectionBackground());
	} else {
	    setBackground(tree.getBackground());
	    setForeground(tree.getForeground());
	}

	if (hasFocus) {
	    setBorder(focusBorder);
	} else {
	    setBorder(noFocusBorder);
	}

	return this;
    }

}

/**
  * This class controls how each cell in a list is rendered.
  * DirIconMap contains a mapping of object class names to
  * icons. If an object's class does not have an entry in
  * this map, its icon is the default
  * (either a folder if it is a context, or the a filled dot).
  * <p>
  * This class is almost identical to BasicListCellRenderer
  * except for how it renders both the icon and text.
  */

    static Border noFocusBorder = new EmptyBorder(1, 1, 1, 1);
    static Border focusBorder = new LineBorder(Color.red, 1);

class DirListCellRenderer extends JLabel implements ListCellRenderer {

    public DirListCellRenderer() {
	setOpaque(true);
	setBorder(noFocusBorder);
    }

    public Component getListCellRendererComponent(
	JList list,
	Object value,
	int index,
	boolean isSelected,
	boolean hasFocus) {
	
	// Set background depending whether cell is selected
	if (isSelected) {
	    setBackground(list.getSelectionBackground());
	    setForeground(list.getSelectionForeground());
	} else {
	    setBackground(list.getBackground());
	    setForeground(list.getForeground());
	}
	
	DirTreeNode node = (DirTreeNode)value;
	DirData realObj = (DirData)node.getUserObject();
	String className = realObj.getClassName();

	setText(realObj.getName());

	Icon icon = DirIconMap.get(className);

	if (icon == null) {
	    icon = (realObj.isContext() ? closedIcon : leafIcon);
	}
	if (icon != null) {
	    setIcon(icon);
	}

	setFont(list.getFont());
	setBorder((hasFocus) ? focusBorder : noFocusBorder);
	return this;
    }
}
    static public void debugName(String msg, String cn) {
	if (debug) {
	    System.out.print(msg + " [");
	    //	    System.out.print("size: " + cn.size());
	    System.out.println("name: " + cn.toString() + "]");
	}
    }

}

