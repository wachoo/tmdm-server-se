/*
 * Copyright (c) 1998 Sun Microsystems, Inc. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * "@(#)CreateDialog.java	1.1	99/05/06 SMI"
 */

package examples.browser;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import javax.naming.directory.*;
import javax.naming.*;

/**
  * This class implements a dialog for accepting arguments for 
  * creating a new object in the namespace. The dialog is
  * initialized using attributes from the parent context in
  * which the new object will be created. The user can then
  * change these attributes.
  *
  * If the attributes are specified, DirContext.createSubcontext()
  * will be used. Otherwise, Context.createSubcontext() will be used.
  *
  * @author Rosanna Lee
  */

class CreateDialog extends AttrDialog {

    // Button that executes "create" operation
    JButton create;

    // parent context in which creation is performed
    Context parentCtx;

    // Listener to notify when node has been created
    CreateListener listener;

    CreateDialog(Context ctx, String parent, Attributes attrs) {
	super("Create new entry under '" + parent + "'");

	parentCtx = ctx;

	// Create "create" button
	create = new JButton("Create");
	create.setToolTipText("create entry in directory");
	create.addActionListener(new CreateActionHandler());

	// Create text field for entering name

	init(attrs, create, createNameField());
    }

    // Sets up text field for entering name of object to create.
    JTextField nameField;
    Component createNameField() {

	// Initialize search filter field with previous search filter
        nameField = new JTextField();
	nameField.setFont(Browser.largeTextFont);
        nameField.setPreferredSize(new Dimension(50, 25));
        nameField.setMaximumSize(new Dimension(Short.MAX_VALUE, 25));
	nameField.setEditable(true);
        nameField.setText("");
	//	nameField.setBackground(Color.white);
	nameField.setToolTipText("enter name of object");

	// Add filter field to titled panel
        JPanel titlePanel = new JPanel(new BorderLayout());
	titlePanel.setBorder(BorderFactory.createTitledBorder("Name"));
        titlePanel.add(nameField, BorderLayout.CENTER);

	JPanel p = new JPanel(new BorderLayout());
	p.add(titlePanel, BorderLayout.CENTER);
	p.add(Box.createRigidArea(new Dimension(10, 10)), BorderLayout.SOUTH);

	return p;
    }

    // Add listener to receive notification when creation is complete.
    void addCreateListener(CreateListener listener) {
	this.listener = listener;
    }

    // Perform creation
    class CreateActionHandler implements ActionListener {
	public void actionPerformed(ActionEvent evt) {
	    try {
		waitCursor();
		// Convert tableModel to Attributes
		Attributes newAttrs = tableModel.toAttributes();

		// Get name of object to create
		String name = nameField.getText();

		Context answer = null;

DirPanel.debugName("create subcontext", name);
System.out.println("using attributes: " + newAttrs);

		if (newAttrs == null || newAttrs.size() == 0) {
		    answer = parentCtx.createSubcontext(name);
		} else if (parentCtx instanceof DirContext) {
		    answer = 
			((DirContext)parentCtx).createSubcontext(name, newAttrs);
		} else {
		    setStatus("Can only create with attributes in DirContext");
		    return;
		}

		listener.objectCreated(name, answer, newAttrs);

		// Get rid of window
		CreateDialog.this.dispose();
	    } catch (NamingException e) {
		// Indicate error and leave window up
		if (debug) e.printStackTrace();
		setStatus(e);
	    } finally {
		restoreCursor();
	    }
	}
    }
}
