/*
 * Copyright (c) 1998 Sun Microsystems, Inc. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * "@(#)AttrDialog.java	1.1	99/05/06 SMI"
 */

package examples.browser;

import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JOptionPane;
import javax.swing.JFrame;
import javax.swing.ImageIcon;
import javax.swing.Icon;
import javax.swing.table.*;
import javax.swing.event.*;

import java.awt.*;
import java.awt.event.*;
import java.util.Vector;

import javax.naming.directory.*;
import javax.naming.*;

import sun.audio.*; // for audio
import java.io.ByteArrayInputStream;
import java.io.IOException;

/**
  * This class implements a frame for viewing and modifying the 
  * attribute ids and values of an object.
  * Attribute value pairs are displayed in two columns, one for
  * the attribute id and one for the attribute value.
  * A multivalued attribute will have multiple rows.
  *<p>
  * If a user changes the ids or values, the changes
  * will then be applied to the underlying directory.
  * This is done by first removing those attributes that have
  * been deleted or renamed using modifyAttributes() with REMOVE_ATTRIBUTE,
  * and then replacing any values that have been modified or added 
  * using modifyAttributes() with REPLACE_ATTRIBUTE. This replaces the
  * attributes that are currently associated with the object with
  * those specified in this AttrTable. An alternate implementation
  * is to maintain a modification list and use the form
  * of modifyAttributes() that accepts an array of ModificationItem.
  *
  * @author Rosanna Lee
  */
class AttrDialog extends JFrame {
    static final boolean debug = true;

    // Heading for table
    static final String[] heading = {"Attribute" , "Value"};

    // Context in which object with these attributes were named. 
    DirContext ctx;

    // Name of object
    String name;

    // Original set of attributes associated with object
    Attributes orig;

    // Table data (attribute's ids and values)
    AttrTableModel tableModel;

    // Table displaying the attribute ids and values
    JTable table;

    // Status bar
    JLabel status = new JLabel("Ready");

    // Table cell Renderer
    TableCellRenderer renderer;
    AudioVideoChecker avChecker;

    // Constructor used by subclasses
    AttrDialog(String title) {
	super(title);
    }

    // Constructs a new instance (used by DirPanel)
    AttrDialog(DirContext ctx, String name, Attributes attrs) {
	super("Attributes for '" + name + "'");

	this.ctx = ctx;
	this.name = name;

	init(attrs, null, null);
    }

    // initialize frame
    void init(Attributes attrs, JButton aButton, Component header) {

	this.orig = attrs;

	// Create table to hold attribute ids and values
	tableModel = new AttrTableModel(attrs);
	table = new JTable(tableModel);

	// Set table cell renderer which knows to play audio
	// for 'audio' attributes and display iconic table entries.
	renderer = new AttrCellRenderer(); 
	table.getColumn(heading[1]).setCellRenderer(renderer);

	// Add to table's list selection model to deal with audio
	avChecker = new AudioVideoChecker();
	table.getSelectionModel().addListSelectionListener(avChecker);

	// Add table to scroller
	JScrollPane tablePane = new JScrollPane(table);
        tablePane.setPreferredSize(new Dimension(500, 100));
		
	// Create panel to hold table and control buttons
	JPanel panel = new JPanel(new BorderLayout());
	panel.add(tablePane, BorderLayout.CENTER);
	panel.add(createButtonPanel(aButton), BorderLayout.SOUTH);

	// Add panel to frame
	if (header != null) {
	    getContentPane().add(header, BorderLayout.NORTH);
	}
	getContentPane().add(panel, BorderLayout.CENTER);
	setBackground(Color.lightGray);

	// Ensures that frame will be destroyed
	addWindowListener( new WindowAdapter() {
	    public void windowClosing(WindowEvent e) {
		dispose();}} );

	// Make frame visible
	pack();
	show();
    }


    /**
     * Creates a row of buttons that apply to table entries.
     */
    JButton add, remove, apply, dismiss, reload;

    JPanel createButtonPanel(JButton applyButton) {
	GridLayout layout = new GridLayout(1, 5);
	layout.setHgap(5); 	// minimum horizontal gap of 5

	// Create anel for holding buttons
	JPanel panel = new JPanel(layout);

	// Create buttons

	add = new JButton("Add");
	add.setToolTipText("add line for entering new attribute");
	add.addActionListener(new AddActionHandler());

	remove = new JButton("Remove");
	remove.setToolTipText("removed selected attribute(s)");
	remove.addActionListener(new RemoveActionHandler());

	if (applyButton == null) {
	    apply = new JButton("Apply");
	    apply.setEnabled(false); // disable until a change is made
	    apply.setToolTipText("apply changes to directory");
	    apply.addActionListener(new ApplyActionHandler());
	} else {
	    apply = applyButton;
	}

	dismiss = new JButton("Dismiss");
	dismiss.setToolTipText("dismiss window");
	dismiss.addActionListener(new DismissActionHandler());

	reload = new JButton("Reload");
	reload.setToolTipText("reset attributes to their original values");
	reload.addActionListener(new ReloadActionHandler());

	// Add to panel
	panel.add(add);
	panel.add(remove);
	panel.add(apply);
	panel.add(dismiss);
	panel.add(reload);

	// Create panel containing buttons and status bar
	JPanel p2 = new JPanel(new BorderLayout());
	p2.add(panel, BorderLayout.CENTER);
	p2.add(status, BorderLayout.SOUTH);

	return p2;
    }

    /**
     * Adds a blank row to table for entering new a attribute.
     */
    class AddActionHandler implements ActionListener {
	public void actionPerformed(ActionEvent evt) {
	    // Create new row in table
	    int where = tableModel.addEmptyRow();

	    // Notify table of change
	    table.tableChanged(new TableModelEvent(tableModel,
		where, where, TableModelEvent.ALL_COLUMNS, 
		TableModelEvent.INSERT));

	    // Apply button now can be used
	    apply.setEnabled(true);
	}
    }

    /**
     * Removes all selected rows.
     */
    class RemoveActionHandler implements ActionListener {
	public void actionPerformed(ActionEvent evt) {

	    // Remove selected row
	    int[] where = tableModel.removeRows();
	    if (where.length == 0) {
		// if none selected/removed, do nothing
		return;
	    }

	    // Notify table of change
	    table.tableChanged(new TableModelEvent(tableModel,
		where[0], where[where.length-1], 
		TableModelEvent.ALL_COLUMNS, 
		TableModelEvent.DELETE));

	    // Apply button now can be used
	    apply.setEnabled(true);
	}
    }

    /**
     * Applies changes made to table to underlying directory.
     * First convert contents of table into an 'Attributes',
     * and then use modifyAttributes() to replace
     * any existing attributes.
     */
    class ApplyActionHandler implements ActionListener {
	public void actionPerformed(ActionEvent evt) {
	    // Convert tableModel to Attributes
	    Attributes newAttrs, oldAttrs;

	    try {
		newAttrs = tableModel.toAttributes();
		oldAttrs = findOldAttrs(orig, newAttrs);
	    } catch (InvalidAttributeIdentifierException e) {
		// invalid attributes
		setStatus(e);
		return;
	    }

	    if (newAttrs != null || oldAttrs != null) {
		try {
		    waitCursor();
		    // Perform update 

DirPanel.debugName("modify attributes", name);
if (debug) {
System.out.println("removing attributes: " + oldAttrs);
System.out.println("replacing attributes: " + newAttrs);
}

		    // Remove first so that we don't get any
		    // NoSuchAttributeException
		    if (oldAttrs != null && oldAttrs.size() > 0)
			ctx.modifyAttributes(name,
			    DirContext.REMOVE_ATTRIBUTE, oldAttrs);

		    if (newAttrs != null && newAttrs.size() > 0)
			ctx.modifyAttributes(name,
			    DirContext.REPLACE_ATTRIBUTE, newAttrs);


		    // Get rid of window
		    AttrDialog.this.dispose();
		} catch (NamingException e) {
		    // Indicate error and leave window up
		    if (debug) e.printStackTrace();
		    setStatus(e);
		} finally {
		    restoreCursor();
		}
	    }
	}
    }

    // Find attributes that exist in oldAttrs but not in newAttrs
    static Attributes findOldAttrs(Attributes oldAttrs, Attributes newAttrs) {
	if (newAttrs == null || newAttrs.size() == 0 || 
	    oldAttrs == null || oldAttrs.size() == 0) {
	    return oldAttrs;
	}

	NamingEnumeration oldNames = oldAttrs.getIDs();
	Attributes dels = new BasicAttributes(true);
	String id;
	while (oldNames.hasMoreElements()) {
	    id = (String)oldNames.nextElement();
	    if (newAttrs.get(id) == null) {
		dels.put(oldAttrs.get(id));
	    }
	}
	return dels;
    }

    /**
     * Dismisses window without apply changes.
     */
    class DismissActionHandler implements ActionListener {
	public void actionPerformed(ActionEvent evt) {
	    // Get rid of window
	    AttrDialog.this.dispose();
	}
    }

    /**
     * Reinitializes table using original attributes with
     * which this Attribute Dialog window was created.
     * Any edits are lost.
     */
    class ReloadActionHandler implements ActionListener {
	public void actionPerformed(ActionEvent evt) {
	    // Forget about any edits, revert to original.
	    // More draconian approach would be to load from directory
	    // (i.e. call getAttributes() again).

	    // Replace data
	    tableModel = new AttrTableModel(orig);
	    table.setModel(tableModel);
	    table.getColumn(heading[1]).setCellRenderer(renderer);

	    // Notify table of change
	    table.tableChanged(new TableModelEvent(tableModel));

	    // Disable Apply button (no change yet)
	    apply.setEnabled(false);
	}
    }

    /**
     * Model that represents data of AttrDialog table.
     * It represents the attributes as two Vectors, one for attribute
     * ids and one for attribute values.
     */
    class AttrTableModel extends AbstractTableModel {
	Vector ids, values;

	AttrTableModel(Attributes attrs) {
	    toVectors(attrs);
	}

	// Convert Attributes into two vectors (ids and values)
	void toVectors(Attributes attrs) {
	    if (attrs == null || attrs.size() == 0) {
		ids = new Vector(10);
		values = new Vector(10);
		return;
	    }
	    try {
		// Just approximation, since there can be multivalued attributes.
		ids = new Vector(attrs.size());
		values = new Vector(attrs.size());

		Attribute attr;
		for(NamingEnumeration enum = attrs.getAll();
		    enum.hasMore();) {
		    attr = (Attribute)enum.next();
		    if (attr.size() > 1) {
			String id = attr.getID();
			// Multivalued.
			for (NamingEnumeration vals = attr.getAll();
			     vals.hasMore();) {
			    ids.addElement(id);
			    values.addElement(vals.next());
			}
		    } else {
			ids.addElement(attr.getID());
			try {
			    values.addElement(attr.get());
			} catch (NamingException e) {
			    if (debug) e.printStackTrace();
			    values.addElement(null);
			}
		    }
		}
	    } catch (NamingException e) {
		if (debug) e.printStackTrace();
		setStatus(e);
	    }
	}

	// Convert table model into an Attributes
	Attributes toAttributes() throws InvalidAttributeIdentifierException {
	    int count = ids.size();
	    Attributes attrs = new BasicAttributes(true); // caseIgnore
	    Attribute attr;
	    String id;
	    Object value;
	    for (int i = 0; i < count; i++) {
		id = (String)ids.elementAt(i);
		if (id.equals("")) {
		    throw new 
			InvalidAttributeIdentifierException("Empty attribute id");
		}
		value = values.elementAt(i);
		if (value instanceof String) {
		    if (((String)value).equals("")) {
			value = null; // assume empty string denotes null
		    }
		}
		if ((attr = attrs.get(id)) != null && attr.size() > 0) {
		    attr.add(value);
		} else {
		    attrs.put(new BasicAttribute(id, value));
		}
	    }
	    return attrs;
	}

	public int getColumnCount() { 
	    return heading.length; 
	}

	public int getRowCount() { 
	    return ids.size();
	}

	/**
	 * Returns the attribute id or value in the table.
  	 * Do special casing for jpegPhoto, audio and binary attributes:
  	 * jpegPhoto: Render an image described by the attribute value
	 * audio: Return a "speaker" icon which when selected will
 	 * 	  play the audio.
	 * binary: all other binary attributes are indicated by the
	 *  	   label "** binary **"
  	 *
	 * Note that the classification of attribute values uses
	 * its attribute id. One could use the schema, but that
	 * many services do not support schema.
         *
	 * Note also that the image displayed is shrunken to fit
	 * into the table. When you click on the attribute, the
	 * image is displayed in its original size.
         * An alternative is to not shrink the image
	 * and provide a slider for increasing the table's row height.
 	 * (There is no way to control individual row heights in JTable.)
         */
	public Object getValueAt(int row, int col) {
	    if (col == 0) {
		// attribute ID
		return ids.elementAt(row);
	    } else {
		// attribute value
		Object obj = values.elementAt(row);
		if (obj instanceof String) {
		    return obj;
		}

		// If value is not String (i.e. binary)
		// treat try to render jpegPhoto,
		// and create voice button for audio.
		// All others, just say "** binary **".

		String id = (String)ids.elementAt(row);
		if (id.equalsIgnoreCase("jpegPhoto")) {
		    // Get image and shrink to fit within row
		    ImageIcon orig = new ImageIcon((byte[])obj);
		    Image im = orig.getImage();
		    Image shrunken = 
			im.getScaledInstance(-1, table.getRowHeight(),
			    Image.SCALE_DEFAULT);
		    orig.setImage(shrunken);
		    return orig;
		} else if (id.equalsIgnoreCase("audio")) {
		    return Browser.speakerIcon;
		} else {
		    return "** binary **";
		}
	    }
	}

	public String getColumnName(int column) {
	    return heading[column];
	}

	public boolean isCellEditable(int row, int col) {
	    if (col == 0)
		return true; // attribute ID is always editable
	    else {
		// only String values are editable
		Object obj = values.elementAt(row);
		return (obj instanceof String);
	    }
	}

	public void setValueAt(Object aValue, int row, int col) {
	    if (col == 0) {
		// Modifying attribute ID
		ids.setElementAt(aValue, row);
	    } else {
		values.setElementAt(aValue, row);
	    }
	    apply.setEnabled(true);
	}

	public int addEmptyRow() {
	    ids.addElement("");
	    values.addElement("");
	    if (debug) System.err.println("Added: " + (ids.size() - 1));
	    return ids.size() - 1 ;
	}

	public int[] removeRows() {
	    // Before removal, stop editing
	    table.editingStopped(new ChangeEvent(table));

	    int[] selected = table.getSelectedRows();
	    // returned array is always ordered
	    // from lowest to highest index

	    // start from back so deletions do not change indices
	    // (deleting an element from a Vector shifts the indices)
	    for (int i = selected.length-1; i >= 0; i--) {
		if (debug) {
		    System.err.println("removing " + selected[i] + ":" + 
			ids.elementAt(selected[i]));
		}
		ids.removeElementAt(selected[i]);
		values.removeElementAt(selected[i]);
	    }
	    return selected;
	}
    }; 


    /**
     * Renderer for cells in AttrDialog table.
     * Each cell can be rendered as an text label or an icon.
     * (JTable's default will choose a renderer for a column based on
     * the first entry in a column. Our renderer will allow
     * icons to appear anywhere in the table and be rendered as such
     * without depending on the top entry in the column.
     */
    class AttrCellRenderer extends DefaultTableCellRenderer {

	public void setValue(Object value) {
	    if (value instanceof Icon) {
		Icon icon = (Icon)value;
		setIcon(icon);
		setText("");
	    } else {
		setIcon(null);
		super.setValue(value);
	    }
	}
    }

    /**
     * If audio attribute has been selected, play its associated 
     * attribute value as an audio stream.
     */
    class AudioVideoChecker implements ListSelectionListener {

	public void valueChanged(ListSelectionEvent evt) {

	    int first = evt.getFirstIndex();
	    int last = evt.getLastIndex();

	    if (first != last || first < 0) 
		return; 

	    String id = (String)tableModel.ids.elementAt(first);
	    if (id.equalsIgnoreCase("audio")) { 
		byte[] soundBytes = (byte[]) tableModel.values.elementAt(first);
		// Play audio
		try {
		    AudioStream as = new AudioStream(
			new ByteArrayInputStream(soundBytes));

		    AudioPlayer.player.start(as);
		} catch (IOException e) {
		    System.err.println("Cannot play audio");
		}
	    } else if (id.equalsIgnoreCase("jpegPhoto")) {
		byte[] bytes= (byte[]) tableModel.values.elementAt(first);
		JOptionPane.showMessageDialog(AttrDialog.this,
		    new JLabel(new ImageIcon(bytes)),
		    "jpegPhoto", JOptionPane.PLAIN_MESSAGE);
	    }
	}
    }

    /**
     * Methods for handling status line of AttrDialog.
     */
    void setStatus(String s, boolean beep) {
	if (beep) 
	    java.awt.Toolkit.getDefaultToolkit().beep();
	status.setText(s);
    }

    void setStatus(String s) {
	setStatus(s, true);
    }

    void setStatus(Exception e) {
	setStatus(e.getClass().getName());
	Browser.appendToConsole(e);
    }

    void resetStatus() {
	status.setText("Ready");
    }

    /**
     * Methods for handling stop watch cursor.
     */
    Cursor savedCursor;
    void waitCursor() {
	savedCursor = getCursor();
	setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
    }

    void restoreCursor() {
	setCursor(savedCursor);
    }
}
