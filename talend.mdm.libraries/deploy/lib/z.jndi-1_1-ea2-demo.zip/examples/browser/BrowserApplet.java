/*
 * Copyright (c) 1998 Sun Microsystems, Inc. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * "@(#)BrowserApplet.java	1.1	99/05/06 SMI"
 */

package examples.browser;

import javax.swing.JApplet;
import javax.swing.JButton;
import java.awt.BorderLayout;
import java.util.Vector;

/**
  * This class encapsulates Browser into an applet.
  * Instead of arguments to the command line for initializing each
  * panel, this applet finds the initialization arguments in the
  * applet parameters named 'providerN' where N is the N'th panel.
  * The value of each parameter has the same format as the command line
  * parameters. See browser.html for examples.
  *<p>
  * You need a Web Browser that can run Swing 1.0.
  *
  * @author Rosanna Lee
  */
public class BrowserApplet extends JApplet {

    public void init() {
	getContentPane().add(new Browser(this, getParams()), BorderLayout.CENTER);
    }

    // Get applet's parameters to construct initialization strings for Browser
    String[] getParams() {
	Vector vec = new Vector();

	for (int i = 0; true; i++) {
	    String param = getParameter("provider" + i);
	    if (param != null) {
		vec.addElement(param);
	    } else {
		break;
	    }
	}
	String[] answer = new String[vec.size()];
	for (int i = 0; i < answer.length; i++) {
	    answer[i] = (String)vec.elementAt(i);
	}
	return answer;
    }
}
