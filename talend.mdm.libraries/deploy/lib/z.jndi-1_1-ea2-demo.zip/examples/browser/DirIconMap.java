/*
 * Copyright (c) 1998 Sun Microsystems, Inc. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * "@(#)DirIconMap.java	1.1	99/05/06 SMI"
 */

package examples.browser;

import javax.swing.ImageIcon;
import javax.swing.Icon;
import java.util.Hashtable;
import java.util.PropertyResourceBundle;
import java.io.IOException;
import java.net.URL;

/**
  * A properties file with the name "iconmap.properties" has a mapping of
  * class names to image file name.
  * 	java.lang.String=string.gif
  *     com.wiz.Coffee=coffeecup.gif
  *     com.wiz.Person=person.gif
  *
  * A class can also have an expanded version of the icon.
  *     java.lang.File=openFolder.gif
  *     java.lang.File/expanded=openFolder.gif
  *
  * The image files and iconmap.properties files are located in the 
  * Browser.IMAGE_DIR directory.
  *
  * @author Rosanna Lee
  */

class DirIconMap {
    static Hashtable icons = new Hashtable(11);
    static PropertyResourceBundle iconBundle = null;
    static boolean loaded = false;

    static PropertyResourceBundle loadIconMap() {
	if (loaded)
	    return iconBundle;

	loaded = true;
	URL url = Browser.browser.getResource(
	    Browser.IMAGE_DIR+ "iconmap.properties");
	if (url == null) {
	    System.err.println(Browser.IMAGE_DIR+"iconmap.properties"+ " not found");
	    return null;
	}
	try {
	    iconBundle = new PropertyResourceBundle(url.openStream());
	} catch (IOException e) {
	    System.err.println("Cannot read iconmap.properties: " + e);
	}
	return iconBundle;
    }

    static Icon get(String name) {
	return get(name, false);
    }

    static Icon get(String origName, boolean isExpanded) {
	if (origName == null) {
	    System.out.println("DirIconMap got a null icon name");
	    return null;
	}

	String name = (isExpanded ? origName + "/expanded" : origName);

	ImageIcon i = (ImageIcon)icons.get(name);
	if (i != null) {
	    return i; // already cached
	}

	if (loadIconMap() == null)
	    return null;

	// Get file name from bundle and try to load in icon
	String fileName = (String)iconBundle.handleGetObject(name);

	// If not found and is expanded, try without "/expanded" suffix.
	if (fileName == null) {
	    if (isExpanded) {
		return get(origName, false);
	    }
	    return null;
	}

	try {
	    i = Browser.browser.loadImageIcon(fileName, "");
	    icons.put(name, i);
	    return i;
	} catch (Exception e) {
	}

	return null; // could not get image file 
    }
}

