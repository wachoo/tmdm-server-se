/*
 * Copyright (c) 1998 Sun Microsystems, Inc. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * "@(#)CreateListener.java	1.1	99/05/06 SMI"
 */

package examples.browser;

import java.util.EventListener;
import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.directory.Attributes;

/**
 * This interface is for accepting notification when a new entry
 * has been created in the namespace and the GUI needs to be updated.
 *
 * @author Rosanna Lee
 */
interface CreateListener extends EventListener {
    void objectCreated(String name, Context ctx, Attributes attrs);
}
