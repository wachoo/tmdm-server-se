/*
 * Copyright (c) 1998 Sun Microsystems, Inc. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * "@(#)HelpDialog.java	1.1	99/05/06 SMI"
 */

package examples.browser;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.text.*;

import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.io.File;
import java.net.URL;
import java.net.URLConnection;
import java.net.MalformedURLException;

/**
  * This class implements a frame that displays HTML text describing 
  * how to use the JNDI browser. It is based on HtmlPanel in the SwingSet
  * demo by  Jeff Dinkins and Tim Prinzing.
  *
  * Note that the hyperlinks do not work because the Swing's HTML editor
  * doesn't seem to handle URL fragments yet.
  *
  * @author Rosanna Lee
  */

class HelpDialog extends JFrame implements HyperlinkListener {
    JEditorPane html;

    HelpDialog(URL helpFile) {
	super("JNDI Browser Help");

        setBackground(Color.white);

	// Workaround for Swing/Net? bug.
	// Must add this because URLConnection doesn't return
	// correct type for resource URL
	JEditorPane.registerEditorKitForContentType("content/unknown", 
	    "javax.swing.text.html.HTMLEditorKit");

	Object obj;
	if (helpFile == null) {
	    System.err.println("Help document not found");
	    this.dispose();
	    return;
	} 
	try {
	    html = new JEditorPane(helpFile);
	    html.setEditable(false);
	    html.addHyperlinkListener(this);
	} catch (IOException e) {
	    System.err.println("Cannot open help document: " + e);
	    this.dispose();
	    return;
	}

	// Put editor inside scroller
	JScrollPane scroller = new JScrollPane();
	scroller.setPreferredSize(new Dimension(400,400));
	JViewport vp = scroller.getViewport();
	vp.add(html);
	vp.setBackingStoreEnabled(true);

	// Add scroller to frame
	getContentPane().add(scroller, BorderLayout.CENTER);

	// Ensures that frame will be destroyed
	addWindowListener( new WindowAdapter() {
	    public void windowClosing(WindowEvent e) {
		dispose();}} );

	// make visible
	show();
	pack();
    }

    /**
     * Notification of a change relative to a hyperlink.
     * %%% From HtmlPane.java in SwingSet example
     */
    public void hyperlinkUpdate(HyperlinkEvent e) {
	if (e.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {
System.out.println("Hyper link event " + e);
	    linkActivated(e.getURL());
	}
    }

    /**
     * Follows the reference in an
     * link.  The given url is the requested reference.
     * By default this calls <a href="#setPage">setPage</a>,
     * and if an exception is thrown the original previous
     * document is restored and a beep sounded.  If an 
     * attempt was made to follow a link, but it represented
     * a malformed url, this method will be called with a
     * null argument.
     *
     * @param u the URL to follow
     *
     * %%% from HtmlPanel.java in SwingSet example
     */
    protected void linkActivated(URL u) {
System.out.println("link activated: " + u);
	Cursor c = html.getCursor();
	Cursor waitCursor = Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR);
	html.setCursor(waitCursor);
	SwingUtilities.invokeLater(new PageLoader(u, c));
    }

    /**
     * temporary class that loads synchronously (although
     * later than the request so that a cursor change
     * can be done).
     *
     * %%% from HtmlPanel.java in SwingSet example
     */
    class PageLoader implements Runnable {
	
	PageLoader(URL u, Cursor c) {
	    url = u;
	    cursor = c;
	}

        public void run() {
	    if (url == null) {
		// restore the original cursor
		html.setCursor(cursor);

		// PENDING(prinz) remove this hack when 
		// automatic validation is activated.
		Container parent = html.getParent();
		parent.repaint();
	    } else {
		Document doc = html.getDocument();
		try {
		    html.setPage(url);
		} catch (IOException ioe) {
		    html.setDocument(doc);
		    getToolkit().beep();
		} finally {
		    // schedule the cursor to revert after
		    // the paint has happended.
		    url = null;
		    SwingUtilities.invokeLater(this);
		}
	    }
	}

	URL url;
	Cursor cursor;
    }
}
