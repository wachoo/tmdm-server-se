/*
 * Copyright (c) 1998 Sun Microsystems, Inc. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * "@(#)SearchDialog.java	1.1	99/05/06 SMI"
 */

package examples.browser;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.tree.MutableTreeNode;

import java.awt.*;
import java.awt.event.*;

import javax.naming.*;
import javax.naming.directory.*;

/**
  * This class implements a dialog for specifying and executing
  * a search on the selected tree node.
  * It consists of fields and widgets for specifying the search
  * filter and search controls. These settings are remembered between 
  * invocations so that they can be reused between searches.
  *
  * @author Rosanna Lee
  */
class SearchDialog extends JFrame implements ActionListener {
    static final boolean debug = true;

    // Name of object or context in which to start search
    String name;

    // Context in which 'name' is named
    DirContext ctx;


    // Maintained between searches
    static SearchControls origctls = new SearchControls();
    static String searchFilter = "";

    // Status bar
    JLabel status = new JLabel("Ready");

    SearchControls ctls;

    SearchListener listener;

    SearchDialog(DirContext ctx, String name) {
	super("Search starting at '" + name + "'");

	this.ctx = ctx;
	this.name = name;

	ctls = cloneControls(origctls);

	// Create panel containing the three elements of the dialog box:
        // the search filter, control buttons, and search controls

	JPanel outer = new JPanel(new BorderLayout());
	//	box.setLayout(new BoxLayout(box, BoxLayout.Y_AXIS));
	outer.setBorder(new EmptyBorder(10, 10, 0, 10));

	JPanel top = new JPanel(new BorderLayout());
	top.add(createSearchFilterField(), BorderLayout.NORTH);
	top.add(createButtonPanel(), BorderLayout.SOUTH);

	JPanel bottom = new JPanel(new BorderLayout());
	bottom.add(createSearchControlsPanel(), BorderLayout.CENTER);
	bottom.add(status, BorderLayout.SOUTH);

	outer.add(top, BorderLayout.NORTH);
	outer.add(bottom, BorderLayout.SOUTH);

	// Add panel to frame
	getContentPane().add(outer, BorderLayout.CENTER);
	setBackground(Color.lightGray);

	// Ensures that frame will be destroyed
	addWindowListener( new WindowAdapter() {
	    public void windowClosing(WindowEvent e) {
		dispose();}} );

	// Make frame visible
	pack();
	show();
    }

    // Sets up text field for entering search filter.
    JTextField filterField;
    Component createSearchFilterField() {

	// Initialize search filter field with previous search filter
        filterField = new JTextField();
	filterField.setFont(Browser.largeTextFont);
        filterField.setPreferredSize(new Dimension(50, 25));
        filterField.setMaximumSize(new Dimension(Short.MAX_VALUE, 25));
	filterField.setEditable(true);
        filterField.setText(searchFilter);
	filterField.setToolTipText("use RFC 2254 syntax");
	//	filterField.setBackground(Color.white);
	filterField.addActionListener(this);

	// Add filter field to titled panel
        JPanel titlePanel = new JPanel(new BorderLayout());
	titlePanel.setBorder(BorderFactory.createTitledBorder("Search Filter"));
        titlePanel.add(filterField, BorderLayout.CENTER);

	return titlePanel;
    }

    // Handles action for performing search
    public void actionPerformed(ActionEvent evt) {
	// Record what user has entered
	searchFilter = filterField.getText();
	origctls = cloneControls(ctls);

	try {
	    waitCursor();

DirPanel.debugName("Search", name);
	    NamingEnumeration results = ctx.search(name, searchFilter, ctls);
	    System.out.println("Search results " + results);
    	    listener.searchCompleted(results);
	    dispose(); // If normal termination, kill window
	} catch (NamingException e) {
	    // Indicate error and leave window up
	    if (debug) e.printStackTrace();
	    setStatus(e);
	} finally {
	    restoreCursor();
	}
    }

    // For now, only one listener is allowed
    void addSearchListener(SearchListener listener) {
	this.listener = listener;
    }


    private SearchControls cloneControls(SearchControls orig) {
	return new SearchControls(
	    orig.getSearchScope(),
	    orig.getCountLimit(),
	    orig.getTimeLimit(),
	    orig.getReturningAttributes(),
	    orig.getReturningObjFlag(),
	    orig.getDerefLinkFlag());
    }

    private void printControls(SearchControls orig) {
	String out;
	switch (orig.getSearchScope()) {
	case SearchControls.ONELEVEL_SCOPE: 
	    out = "one_level";
	    break;
	case SearchControls.OBJECT_SCOPE: 
	    out = "object";
	    break;
	case SearchControls.SUBTREE_SCOPE: 
	    out = "subtree";
	    break;
	default: out = "invalid";
	}
	
	out += " scope; ";
	out += ("count(" + orig.getCountLimit() + ") ");
	out += ("time(" + orig.getTimeLimit() + ")") ;
	out += ("obj(" + orig.getReturningObjFlag() + " ) ");
	out += ("deref(" + orig.getDerefLinkFlag() + " ) ");
	System.err.println(out);
    }

    /**
     * Search controls pane allows user to specify various controls
     * for controls.
     */
    Component createSearchControlsPanel() {

	// On the left column are the search scope combo box and
	// checkboxes for deref and return-object

	JPanel left = new JPanel(new GridLayout(3, 1));
	//	left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
	left.setAlignmentX(Component.LEFT_ALIGNMENT);
	left.setPreferredSize(new Dimension(200, 75));
	createCheckBoxes();
	left.add(createScope());
	left.add(deref);
	left.add(retobj);

	// Create title-border panel to encapsulate controls
        JPanel ctlPanel = new JPanel();
	ctlPanel.setLayout(new BoxLayout(ctlPanel, BoxLayout.X_AXIS));
	ctlPanel.setBorder(BorderFactory.createTitledBorder("Search Controls"));

	ctlPanel.add(left);

	// Add space between left/right columns
	ctlPanel.add(Box.createRigidArea(new Dimension(10, 10)));

	// Add limits text fields
	ctlPanel.add(createLimits());

	return ctlPanel;
    }

    // Create combo box for specifying search scope
    JComboBox scopes;
    Component createScope() {
	scopes = new JComboBox();
	scopes.addItem("object");
	scopes.addItem("one level");
	scopes.addItem("subtree");
	scopes.setSelectedIndex(ctls.getSearchScope());

	scopes.setEditable(false);
	scopes.addItemListener(new ChangeScopeHandler());

	// Create panel to hold label and combo box
	JPanel p = new JPanel();
	p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
	p.setMaximumSize(new Dimension(300, 20));
	p.add(new JLabel("search scope"));
	p.add(Box.createRigidArea(new Dimension(5, 5)));
	p.add(scopes);

	return p;
    }

    class ChangeScopeHandler implements ItemListener {
	public void itemStateChanged(ItemEvent evt) {
	    int which = scopes.getSelectedIndex();
System.out.println("selected: " + which);
	    if (which >= 0) {
		ctls.setSearchScope(which);
	    }
	    if (debug) printControls(ctls);
	}
    }


// -- Flags in search controls
    JCheckBox deref, retobj;
    void createCheckBoxes() {
	deref = new JCheckBox("dereference link", ctls.getDerefLinkFlag());
	deref.setToolTipText("dereference link during search");
	deref.addItemListener(new DerefHandler());

	retobj = new JCheckBox("return object", ctls.getReturningObjFlag());
	retobj.setToolTipText("include object when returning search results");
	retobj.addItemListener(new RetObjHandler());

	// add listeners
    }

    class DerefHandler implements ItemListener {
	public void itemStateChanged(ItemEvent evt) {
	    boolean newState = (evt.getStateChange() == ItemEvent.SELECTED);
	    ctls.setDerefLinkFlag(newState);
	    if (debug) printControls(ctls);
	}
    }

    class RetObjHandler implements ItemListener {
	public void itemStateChanged(ItemEvent evt) {
	    boolean newState = (evt.getStateChange() == ItemEvent.SELECTED);
	    ctls.setReturningObjFlag(newState);
	    if (debug) printControls(ctls);
	}
    }


// -- count/time limits in search controls
    JTextField timeLimit, countLimit;
    Component createLimits() {

	JPanel outer = new JPanel(new GridLayout(2, 2));
	outer.setBorder(BorderFactory.createTitledBorder("Limits"));

	//	left.setAlignmentX(Component.LEFT_ALIGNMENT);
	JLabel l;
	outer.add(l = new JLabel("time"));
	l.setPreferredSize(new Dimension(30, 15));
	timeLimit = new JTextField(ctls.getTimeLimit()+"", 5);
	timeLimit.setPreferredSize(new Dimension(30, 15));
	timeLimit.setMaximumSize(new Dimension(Short.MAX_VALUE, 15));
	timeLimit.setToolTipText("(in ms) terminate search when time is up");
	//	timeLimit.setBackground(Color.white);
	timeLimit.addActionListener(new TimeLimitAction());
	outer.add(timeLimit);

	outer.add(l = new JLabel("count"));
	l.setPreferredSize(new Dimension(30, 15));
	countLimit = new JTextField(ctls.getCountLimit()+"", 5);
	countLimit.setPreferredSize(new Dimension(30, 15));
	countLimit.setMaximumSize(new Dimension(Short.MAX_VALUE, 15));
	//	countLimit.setBackground(Color.white);
	countLimit.setToolTipText("terminate search when number of results found");

	countLimit.addActionListener(new CountLimitAction());
	outer.add(countLimit);

	return outer;
    }

    // Update count limit in search controls
    class CountLimitAction implements ActionListener {
	public void actionPerformed(ActionEvent evt) {
	    String val = countLimit.getText();

	    try {
		long newLimit = Long.parseLong(val);
		ctls.setCountLimit(newLimit);
		if (debug) printControls(ctls);
	    } catch (NumberFormatException e) {
		setStatus("Invalid numeric value");
	    }
	}
    }

    // Update time limit in search controls
    class TimeLimitAction implements ActionListener {
	public void actionPerformed(ActionEvent evt) {
	    String val = timeLimit.getText();

	    try {
		int newLimit = Integer.parseInt(val);
		ctls.setTimeLimit(newLimit);
		if (debug) printControls(ctls);
	    } catch (NumberFormatException e) {
		setStatus("Invalid numeric value");
	    }
	}
    }

// -- Control buttons

    JButton search, dismiss, reload;
    private JPanel createButtonPanel() {
	GridLayout layout = new GridLayout(1, 3);
	JPanel panel = new JPanel(layout);
	panel.setBorder(new EmptyBorder(10, 15, 10, 15));
	layout.setHgap(10); 	// minimum horizontal gap of 10

	search = new JButton("Search");
	search.setToolTipText("search using filter and controls");
	search.addActionListener(this);

	dismiss = new JButton("Dismiss");
	dismiss.setToolTipText("dismiss window");
	dismiss.addActionListener(new DismissActionHandler());

	reload = new JButton("Reload");
	reload.setToolTipText("reload previous filter and controls");
	reload.addActionListener(new ReloadActionHandler());

	panel.add(search);
	panel.add(dismiss);
	panel.add(reload);

	return panel;
    }

    // Gets rid of window 
    class DismissActionHandler implements ActionListener {
	public void actionPerformed(ActionEvent evt) {
	    // Get rid of window
	    SearchDialog.this.dispose();
	}
    }

    // Reload search filter and search controls to previous values
    class ReloadActionHandler implements ActionListener {
	public void actionPerformed(ActionEvent evt) {

	    // Update text field with previous search filter
	    filterField.setText(searchFilter);

	    // Update controls
	    ctls = cloneControls(origctls);

	    // Update GUI
	    timeLimit.setText(ctls.getTimeLimit()+"");
	    countLimit.setText(ctls.getCountLimit()+"");
	    deref.setSelected(ctls.getDerefLinkFlag());
	    retobj.setSelected(ctls.getReturningObjFlag());
	    scopes.setSelectedIndex(ctls.getSearchScope());

	    // Refresh display
	    SearchDialog.this.invalidate();
	    SearchDialog.this.validate();
	    if (debug) printControls(ctls);
	}
    }

// -- Status line 

    void setStatus(String s, boolean beep) {
	if (beep) 
	    java.awt.Toolkit.getDefaultToolkit().beep();
	status.setText(s);
    }

    void setStatus(String s) {
	setStatus(s, true);
    }

    void setStatus(Exception e) {
	setStatus(e.getClass().getName());
	Browser.appendToConsole(e);
    }

    void resetStatus() {
	status.setText("Ready");
    }

// -- Stop watch cursor 
    Cursor savedCursor;
    void waitCursor() {
	savedCursor = getCursor();
	setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
    }

    void restoreCursor() {
	setCursor(savedCursor);
    }
}
