/*
 * Copyright (c) 1998 Sun Microsystems, Inc. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * "@(#)ConsoleDialog.java	1.1	99/05/06 SMI"
 */

package examples.browser;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.text.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.Dimension;
import java.awt.BorderLayout;
import java.awt.GridLayout;

/**
  * This class implements a frame that displays text. Various windows
  * in the browser uses this to display error messages.
  *
  * @author Rosanna Lee
  */

class ConsoleDialog extends JFrame {
    ConsoleDialog(JTextArea t) {
	super("JNDI Browser Console");

	// Put text area inside scroller
	JScrollPane scroller = new JScrollPane();
	scroller.setPreferredSize(new Dimension(400,400));
	scroller.getViewport().add(t);

	// Create panel to hold table and control buttons
	JPanel panel = new JPanel(new BorderLayout());
	panel.add(scroller, BorderLayout.CENTER);
	panel.add(createButtonPanel(), BorderLayout.SOUTH);

	// Add to frame
	getContentPane().add(panel, BorderLayout.CENTER);

	// Ensures that frame will be destroyed
	addWindowListener( new WindowAdapter() {
	    public void windowClosing(WindowEvent e) {
		dispose();}} );

	// make visible
	show();
	pack();
    }

    JPanel createButtonPanel() {
	GridLayout layout = new GridLayout(1, 4);
	layout.setHgap(5); 	// minimum horizontal gap of 5

	// Create anel for holding buttons
	JPanel panel = new JPanel(layout);

	// Create buttons
	JButton dismiss = new JButton("Dismiss");
	dismiss.setToolTipText("dismiss window");
	dismiss.addActionListener(new DismissActionHandler());

	JButton clear = new JButton("Clear");
	clear.setToolTipText("Clear console");
	clear.addActionListener(new ClearActionHandler());

	// Add to panel
	panel.add(new JLabel()); // filler
	panel.add(dismiss);
	panel.add(clear);
	panel.add(new JLabel()); // filler

	return panel;
    }

    /**
     * Dismisses window without apply changes.
     */
    class DismissActionHandler implements ActionListener {
	public void actionPerformed(ActionEvent evt) {
	    // Get rid of window
	    ConsoleDialog.this.dispose();
	}
    }

    /**
     * Clears text area.
     */
    class ClearActionHandler implements ActionListener {
	public void actionPerformed(ActionEvent evt) {
	    Browser.clearConsole();
	}
    }
}
