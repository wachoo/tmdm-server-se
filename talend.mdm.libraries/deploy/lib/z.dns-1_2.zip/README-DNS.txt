	  Java Naming and Directory Interface(TM)
	    DNS Service Provider Release Notes
			 FCS 1.2
		      February 2002

This is the FCS release of the DNS service provider for JNDI.
Please send your feedback to us at jndi@java.sun.com, or to the public
mailing list at jndi-interest@java.sun.com.


CHANGES SINCE TECHNOLOGY PREVIEW 2 (November 2000)

- Added support for using IPv6 literals where host names are called for.
  IPv6 literals should be delimited by brackets.

- Some large internal data structures are now accessed via soft references,
  allowing heap space to be freed when needed.

- JDK 1.1.x is no longer supported.


CHANGES SINCE TECHNOLOGY PREVIEW 1 (June 2000)

- Added support for multiple DNS servers (by setting the Context.PROVIDER_URL
  property to a space-separated list of URLs).

- Added support for doing queries over TCP.  This is used when a DNS
  response is too long to be returned in a UDP packet without being truncated.

- Added support for list operations.  This is implemented using DNS zone
  transfers, so list operations are potentially compute- and network-
  intensive, and they may not be supported by all DNS installations.

- Attribute identifiers now use "*" instead of "" to represent an
  unspecified class or type.  For example:  "IN *".


RELEASE INFORMATION

This release contains:

lib/dns.jar
	Archive of class files for the service provider.

lib/providerutil.jar
	Utilities used by service providers developed by Sun Microsystems.
	The DNS service provider uses some of the classes in this archive.
	If you have downloaded other service providers with their own
	versions of providerutil.jar, it is best to use the most recent
	version (dates are provided in the release notes of each provider).

doc/providers/jndi-dns-ext.html
doc/providers/jndi-dns.html
	Documentation of the service provider.


The classes in this release have been generated using the Java(TM) 2 SDK,
Standard Edition, v1.2.

ADDITIONAL INFORMATION

examples/api (available as part of the general JNDI 1.2 distribution)
	Generic examples for accessing any naming and
	directory service, including DNS. See examples/api/README.

examples/browser (available as a separate download)
	A JNDI browser for browsing any naming and directory
	service, including DNS. See examples/browser/README-DEMO.txt.

http://java.sun.com/products/jndi/1.2/javadoc
	JNDI 1.2 API specification (javadoc).
