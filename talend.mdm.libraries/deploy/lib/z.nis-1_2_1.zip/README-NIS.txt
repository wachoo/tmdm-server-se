	  Java Naming and Directory Interface(TM)
	    NIS Service Provider Release Notes
	                 FCS 1.2.1
		        Nov 16, 1999

This is the 1.2.1 maintenance release of the JNDI NIS service
provider.  Please send your feedback on the NIS service provider to us
at jndi@java.sun.com, or to the public mailing list at
jndi-interest@java.sun.com.


CHANGES SINCE 1.2 FCS

Here are the highlights:

- Wrap thread creation inside doPriviledged for proper functioning in J2EE


RELEASE INFORMATION

This release contains:

lib/nis.jar
	Archive of class files for the service provider.

lib/providerutil.jar
	Utilities used by service providers developed by Sun Microsystems.
	The NIS service provider uses some of the classes in this archive.
	This archive file is interchangeable with the providerutil.jar
	file that you might have downloaded with one of the other service 
	providers from Sun Microsystems.

doc/providers/jndi-nis-ext.html
doc/providers/jndi-nis.html
	Documentation of the service provider.


The classes in this release have been generated using the Java(TM) 2 SDK,
Standard Edition, v1.2.

ADDITIONAL INFORMATION

examples/api (available as part of the general JNDI 1.2 distribution)
	Generic examples for accessing any naming and
	directory service, including NIS. See examples/api/README.

examples/browser (available as a separate download)
	A JNDI browser for browsing any naming and directory
	service, including NIS. See examples/browser/README-DEMO.txt.

http://java.sun.com/products/jndi/1.2/javadoc        
	JNDI 1.2 javadoc.
