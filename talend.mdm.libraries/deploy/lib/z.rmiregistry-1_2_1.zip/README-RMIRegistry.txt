Java(TM) Remote Method Invocation(RMI) Registry Service Provider for the
		Java Naming and Directory Interface(TM)
	                FCS 1.2.1
		      Oct 15, 1999

This is the 1.2.1 maintenance release of the RMI registry service
provider for JNDI.  Please send your feedback to the Sun Microsystems
Java Software Division at jndi@java.sun.com, or to the public mailing
list jndi-interest@java.sun.com.


CHANGES SINCE 1.2 FCS

Here are the highlights:

- Make unbind() idempotent as per JNDI spec

- Make provider treat parameter passing and return values as per JNDI
spec (by performing the necessary cloning).


RELEASE INFORMATION

This release contains:

lib/rmiregistry.jar
	Archive of class files for the service provider.

lib/providerutil.jar
	Utilities used by service providers developed by Sun Microsystems.
	The RMI registry service provider uses some of the classes in this
	archive.  This archive file is interchangeable with the
	providerutil.jar file that you might have downloaded with one of
	the other service providers currently available from Sun Microsystems.

doc/providers/jndi-rmi-ext.html
doc/providers/jndi-rmi.html
	Documentation of the service provider, including usage examples.


The classes in this release have been generated using the Java(TM) 2 SDK,
Standard Edition, v1.2.


ADDITIONAL INFORMATION

examples/api (available as part of the general JNDI1.2 distribution)
	Generic examples for accessing any naming and
	directory service.  The naming examples (List, Lookup, and Rename)
	can be used with the RMI registry.  See examples/api/README.
	When using these example programs, the property
	"java.naming.rmi.security.manager" might need to be set:
	see the "Security Considerations" section of 
        doc/providers/jndi-rmi.html and doc/providers/jndi-rmi-ext.html
	for more information.

http://java.sun.com/products/jndi/1.2/javadoc        
	JNDI 1.2 javadoc.
