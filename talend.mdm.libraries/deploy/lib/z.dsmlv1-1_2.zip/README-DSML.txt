	  Java Naming and Directory Interface(TM)
	    DSML v1 Service Provider Release Notes
		       May 1, 2002

This is the FCS release of the JNDI DSML v1 service provider.  Please
send your feedback on the DSML v1 service provider to us at
jndi@java.sun.com, or to the public mailing list at
jndi-interest@java.sun.com.


SPECIAL INSTRUCTIONS
	doc/providers/jndi-dsml-ext.html contains instructions
	on how to install this provider, including a special note
	for LDAP 1.2.2 users. You must follow these instructions
	if you want to use an LDAP URL for configuring this provider.


CHANGES FROM TECHNOLOGY PREVIEW 2 (Nov, 2000)

- Removed JAXP (jaxp.jar and parser.jar) from distribution; must download 
  JAXP 1.1 separately from http://java.sun.com/products/xml/

- Generation of output produces parent nodes before children node.

- Supports XML namespace (i.e., can use tags other than "dsml").

- Support object factories correctly for lookup(), listBindings(), and search().

- Properly parse DN returned by LDAP service when it contains special characters.


RELEASE INFORMATION

This release contains:

lib/dsml.jar
	Archive of class files for the service provider.

lib/providerutil.jar
	Utilities used by service providers developed by Sun Microsystems.
	The DSML v1 service provider uses some of the classes in this archive.
	This archive file is NOT interchangeable with the providerutil.jar 
        file that you might have downloaded with any other service providers 
	from Sun Microsystems. It is safe for other providers to use this 
	providerutil.jar.

doc/providers/jndi-dsml-ext.html
	Installation instructions.

doc/providers/jndi-dsml.html
	Documentation of the service provider.


The classes in this release have been generated using the Java(TM) 2 SDK,
Standard Edition, v1.2.


ADDITIONAL INFORMATION

http://java.sun.com/products/jndi/#download
	The DSML v1 provider depends on the JNDI and LDAP provider classes.
	You need these classes if you are using J2SDK v1.2.x or JDK 1.1.x.

http://java.sun.com/products/xml/
	The DSML provider depends on Java API for XML Parsing, 
	version 1.1 and higher. You need these classes if you are using
	J2SDK v1.3.x, J2SDK v1.2.x or JDK 1.1.x.

examples/api (available as part of the general JNDI 1.2 distribution)
	Generic examples for accessing any naming and
	directory service, including DSML. See examples/api/README.

examples/browser (available as a separate download)
	A JNDI browser for browsing any naming and directory
	service, including DSML. See examples/browser/README-DEMO.txt.

http://java.sun.com/products/jndi/1.2/javadoc        
	JNDI 1.2 javadoc.
