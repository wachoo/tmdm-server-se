

import HelloApp.*;
 
import org.omg.CORBA.*;
import java.awt.Graphics;
import java.util.Hashtable;

import javax.naming.InitialContext;
import javax.naming.Context;

public class helloApplet2 extends java.applet.Applet 
{
    public void init() {
	try {
	    // create and initialize the ORB
            ORB orb = ORB.init(this, null);
 
	    Hashtable env = new Hashtable(5, 0.75f);
	    env.put("java.naming.corba.orb", orb);

	    // get the root naming context
	    Context ic = new InitialContext(env);
 
            // resolve the Object Reference using JNDI
            hello helloRef = 
	      helloHelper.narrow((org.omg.CORBA.Object)ic.lookup("Hello"));
 
            // call the hello server object and print results
            message = helloRef.sayHello();

	} catch (Exception e) {
	    System.out.println("HelloApplet exception: " + e.getMessage());
	    e.printStackTrace(System.out);
        }
    }

    public void paint(Graphics g) 
    {
	g.drawString(message, 25, 50);
    }

    String message = "";
}
