/*
 * File: ./HelloApp/helloHelper.java
 * From: HelloApp.idl
 * Date: Mon Mar  9 09:08:21 1998
 *   By: idltojava Java IDL 1.2 Nov 12 1997 12:23:47
 */

package HelloApp;
public class helloHelper {
     // It is useless to have instances of this class
     private helloHelper() { }

    public static void write(org.omg.CORBA.portable.OutputStream out, HelloApp.hello that) {
        out.write_Object(that);
    }
    public static HelloApp.hello read(org.omg.CORBA.portable.InputStream in) {
        return HelloApp.helloHelper.narrow(in.read_Object());
    }
   public static HelloApp.hello extract(org.omg.CORBA.Any a) {
     org.omg.CORBA.portable.InputStream in = a.create_input_stream();
     return read(in);
   }
   public static void insert(org.omg.CORBA.Any a, HelloApp.hello that) {
     org.omg.CORBA.portable.OutputStream out = a.create_output_stream();
     write(out, that);
     a.read_value(out.create_input_stream(), type());
   }
   private static org.omg.CORBA.TypeCode _tc;
   synchronized public static org.omg.CORBA.TypeCode type() {
          if (_tc == null)
             _tc = org.omg.CORBA.ORB.init().create_interface_tc(id(), "hello");
      return _tc;
   }
   public static String id() {
       return "IDL:HelloApp/hello:1.0";
   }
   public static HelloApp.hello narrow(org.omg.CORBA.Object that)
	    throws org.omg.CORBA.BAD_PARAM {
        if (that == null)
            return null;
        if (that instanceof HelloApp.hello)
            return (HelloApp.hello) that;
	if (!that._is_a(id())) {
	    throw new org.omg.CORBA.BAD_PARAM();
	}
        org.omg.CORBA.portable.Delegate dup = ((org.omg.CORBA.portable.ObjectImpl)that)._get_delegate();
        HelloApp.hello result = new HelloApp._helloStub(dup);
        return result;
   }
}
