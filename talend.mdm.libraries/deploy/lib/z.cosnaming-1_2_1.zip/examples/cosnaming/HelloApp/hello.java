/*
 * File: ./HelloApp/hello.java
 * From: HelloApp.idl
 * Date: Mon Mar  9 09:08:21 1998
 *   By: idltojava Java IDL 1.2 Nov 12 1997 12:23:47
 */

package HelloApp;
public interface hello
    extends org.omg.CORBA.Object {
    String sayHello()
;
}
