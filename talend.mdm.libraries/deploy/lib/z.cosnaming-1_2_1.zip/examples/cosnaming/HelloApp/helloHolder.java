/*
 * File: ./HelloApp/helloHolder.java
 * From: HelloApp.idl
 * Date: Mon Mar  9 09:08:21 1998
 *   By: idltojava Java IDL 1.2 Nov 12 1997 12:23:47
 */

package HelloApp;
public final class helloHolder
     implements org.omg.CORBA.portable.Streamable{
    //	instance variable 
    public HelloApp.hello value;
    //	constructors 
    public helloHolder() {
	this(null);
    }
    public helloHolder(HelloApp.hello __arg) {
	value = __arg;
    }

    public void _write(org.omg.CORBA.portable.OutputStream out) {
        HelloApp.helloHelper.write(out, value);
    }

    public void _read(org.omg.CORBA.portable.InputStream in) {
        value = HelloApp.helloHelper.read(in);
    }

    public org.omg.CORBA.TypeCode _type() {
        return HelloApp.helloHelper.type();
    }
}
