
import HelloApp.*;

import org.omg.CORBA.ORB;
import org.omg.CORBA.Object;
import javax.naming.InitialContext;
import javax.naming.Context;
import java.util.Hashtable;

public class helloClient2
{
    public static void main(String args[])
    {
	try{
	    // create and initialize the ORB
	    ORB orb = ORB.init(args, null);

	    Hashtable env = new Hashtable(5, 0.75f);
	    env.put("java.naming.corba.orb", orb);

	    // get the root naming context
	    Context ic = new InitialContext(env);

            // resolve the Object Reference using JNDI
            hello helloRef = 
	      helloHelper.narrow((org.omg.CORBA.Object)ic.lookup("Hello"));

	    // call the hello server object and print results
	    String hello = helloRef.sayHello();
	    System.out.println(hello);

	} catch (Exception e) {
	    System.out.println("ERROR : " + e) ;
	    e.printStackTrace(System.out);
	}
    }
}
