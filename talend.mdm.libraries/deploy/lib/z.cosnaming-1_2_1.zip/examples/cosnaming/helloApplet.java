

import HelloApp.*;
 
import org.omg.CosNaming.*;
import org.omg.CosNaming.NamingContextPackage.*;
import org.omg.CORBA.*;
import java.awt.Graphics;

public class helloApplet extends java.applet.Applet 
{
    public void init() {
	try {
	    // create and initialize the ORB
            ORB orb = ORB.init(this, null);
 
            // get the root naming context
            org.omg.CORBA.Object objRef = 
		orb.resolve_initial_references("NameService");
            NamingContext ncRef = NamingContextHelper.narrow(objRef);
 
            // resolve the Object Reference in Naming
            NameComponent nc = new NameComponent("Hello", "");
            NameComponent path[] = {nc};
            hello helloRef = helloHelper.narrow(ncRef.resolve(path));
 
            // call the hello server object and print results
            message = helloRef.sayHello();

	} catch (Exception e) {
	    System.out.println("HelloApplet exception: " + e.getMessage());
	    e.printStackTrace(System.out);
        }
    }

    public void paint(Graphics g) 
    {
	g.drawString(message, 25, 50);
    }

    String message = "";
}
