
import HelloApp.*;

import org.omg.CORBA.ORB;
import javax.naming.InitialContext;
import javax.naming.Context;

import java.util.Hashtable;


class helloServant2 extends _helloImplBase 
{
    public String sayHello()
    {
	return "\nHello world !!\n";
    }
}

public class helloServer2 {

    public static void main(String args[])
    {
	try{
	    // create and initialize the ORB
	    ORB orb = ORB.init(args, null);

	    // create servant and register it with the ORB
	    helloServant2 helloRef = new helloServant2();
	    orb.connect(helloRef);

	    Hashtable env = new Hashtable();
	    env.put("java.naming.corba.orb", orb);

	    // get the root naming context
	    Context ic = new InitialContext(env);

	    // bind the Object Reference using JNDI
	    ic.rebind("Hello", helloRef);

	    // wait for invocations from clients
            java.lang.Object sync = new java.lang.Object();
            synchronized (sync) {
                sync.wait();
            }

	} catch (Exception e) {
	    System.err.println("ERROR: " + e);
	    e.printStackTrace(System.out);
	}
    }
}
