	      Java Naming and Directory Interface(TM) (JNDI)
		COS Naming Service Provider Release Notes
			    FCS 1.2.1
 			   Oct 15, 1999

This is the 1.2.1 maintenance release of the JNDI COS naming service
provider.  Please send your feedback on the COS naming service
provider to us at jndi@java.sun.com, or to the public mailing list at
jndi-interest@java.sun.com.


CHANGES SINCE 1.2 FCS 

Here are the highlights:

- A reference that contains an iiop/iiopname URL should not be 
  restricted to naming a context.

- Fix problem of listing empty context when using other vendor's
  version of JavaIDL.

- Make unbind()/destroySubcontext() idempotent as per JNDI spec

- Make provider treat parameter passing and return values as per JNDI
spec (by performing the necessary cloning).


RELEASE INFORMATION

This release contains:

lib/cosnaming.jar
	Archive of class files for the service provider.

lib/providerutil.jar
	Utilities used by service providers developed by Sun Microsystems.
	The COS naming service provider uses some of the classes in this
	archive. This archive file is interchangeable with the 
	providerutil.jar file that you might have downloaded with one of 
	the other service providers from Sun Microsystems.

doc/providers/jndi-cos-ext.html
doc/providers/jndi-cos.html
	Documentation of the service provider.

examples/cosnaming
	Example for the CORBA programmer. See examples/cosnaming/README.


The classes in this release have been generated using the Java(TM) 2 SDK,
Standard Edition, v1.2.

ADDITIONAL INFORMATION

examples/api (available as part of the general JNDI1.2 distribution)
	Generic examples for accessing any naming and
	directory service. You can use the naming examples (List,
	Lookup, and Rename) with COS naming. See examples/api/README.

examples/browser (available as a separate download)
	contains a JNDI browser for browsing any naming and directory
	service, including the COS name service. 
        See examples/browser/README-DEMO.txt.

http://java.sun.com/products/jndi/1.2/javadoc
	JNDI 1.2 javadoc.







